// The C++ Standard Library From Scratch
// Exercise 6.1

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <vector>
#include <list>
#include <string>
#include <algorithm>
#include <iterator>

// Vector print
void print(const std::vector<std::string>& v)
{
  for (int i = 0; i < v.size(); ++i)
    std::cout << v[i] << " ";
}

// List print
void print(const std::list<std::string>& lst)
{
  for (std::list<std::string>::const_iterator i = lst.begin();
       i != lst.end(); ++i)
    std::cout << *i << " ";
}

int main()
{
  // Create empty list
  std::list<std::string> mylist;

  // Add 5 elements
  mylist.push_back("eggs");
  mylist.push_back("milk");
  mylist.push_back("sugar");
  mylist.push_back("chocolate");
  mylist.push_back("flour");
  std::cout << "5 items in list: ";
  print(mylist);
  std::cout << std::endl;

  // Copy list to a vector using copy algorithm and back inserter
  std::vector<std::string> myvector;
  std::copy(mylist.begin(), mylist.end(), std::back_inserter(myvector));
  std::cout << "copied to vector: ";
  print(myvector);
  std::cout << std::endl;

  std::sort(myvector.begin(), myvector.end());
  std::cout << "sorted vector: ";
  print(myvector);
  std::cout << std::endl;
  
  return 0;
}