// The C++ Standard Library From Scratch
// Exercise 6.2

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <vector>
#include <list>
#include <string>
#include <algorithm>
#include <iterator>
#include <functional>

// Vector print
void print(const std::vector<std::string>& v)
{
  for (int i = 0; i < v.size(); ++i)
    std::cout << v[i] << " ";
}

// List print
void print(const std::list<std::string>& lst)
{
  for (std::list<std::string>::const_iterator i = lst.begin();
       i != lst.end(); ++i)
    std::cout << *i << " ";
}

// Function object for part 3. Returns true if string is equal to specified length
class is_length : public std::unary_function<std::string, bool>
{
public:
  is_length(std::string::size_type len) : len_(len) { }
  bool operator()(const std::string& s) { return s.length() == len_; }
private:
  std::string::size_type len_;
};

int main()
{
  // Create empty list
  std::list<std::string> mylist;

  // Add 5 elements
  mylist.push_back("eggs");
  mylist.push_back("milk");
  mylist.push_back("sugar");
  mylist.push_back("chocolate");
  mylist.push_back("flour");
  std::cout << "5 items in list: ";
  print(mylist);
  std::cout << std::endl;

  // Copy list to a vector using copy algorithm and back inserter
  std::vector<std::string> myvector;
  std::copy(mylist.begin(), mylist.end(), std::back_inserter(myvector));
  std::cout << "copied to vector: ";
  print(myvector);
  std::cout << std::endl;

  // Sort vector
  std::sort(myvector.begin(), myvector.end());
  std::cout << "sorted vector: ";
  print(myvector);
  std::cout << std::endl;
  
  // Sort vector in descending order
  std::sort(myvector.begin(), myvector.end(), std::greater<std::string>());
  std::cout << "descending sort: ";
  print(myvector);
  std::cout << std::endl;

  // Count items less than "flour":
  int vnum = std::count_if(myvector.begin(), myvector.end(), 
                           std::bind2nd(std::less<std::string>(), "flour"));
  int lnum = std::count_if(mylist.begin(), mylist.end(), 
                           std::bind2nd(std::less<std::string>(), "flour"));
  std::cout << "Number less than \"flour\" in vector: " << vnum << std::endl;
  std::cout << "Number less than \"flour\" in list: " << lnum << std::endl;

  // Count items of length 5.
  int len5 = std::count_if(myvector.begin(), myvector.end(), is_length(5));
  std::cout << "Number of length 5: " << len5 << std::endl;

  return 0;
}