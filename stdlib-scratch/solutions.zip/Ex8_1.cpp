// The C++ Standard Library From Scratch
// Exercise 8.1

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <vector>
#include <list>
#include <string>
#include <algorithm>
#include <iterator>

// print algorithm works for vector, list, deque, set and multiset
template <class FwdIter>
void print(FwdIter start, FwdIter end)
{
  for (FwdIter i = start; i != end; ++i)
    std::cout << *i << " ";
}

int main()
{
  // Create empty list
  std::list<std::string> mylist;

  // Add 5 elements
  mylist.push_back("eggs");
  mylist.push_back("milk");
  mylist.push_back("sugar");
  mylist.push_back("chocolate");
  mylist.push_back("flour");
  std::cout << "5 items in list: ";
  print(mylist.begin(), mylist.end());
  std::cout << std::endl;

  // Copy list to a vector using copy algorithm and back inserter
  std::vector<std::string> myvector;
  std::copy(mylist.begin(), mylist.end(), std::back_inserter(myvector));
  std::cout << "copied to vector: ";
  print(myvector.begin(), myvector.end());
  std::cout << std::endl;

  // Sort vector
  std::sort(myvector.begin(), myvector.end());
  std::cout << "sorted vector: ";
  print(myvector.begin(), myvector.end());
  std::cout << std::endl;

  // Print without first and last element
  std::cout << "Omitting first and last element: ";
  print(myvector.begin() + 1, myvector.end() - 1);
  std::cout << std::endl;
  
  return 0;
}