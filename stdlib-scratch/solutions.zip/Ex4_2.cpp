// The C++ Standard Library From Scratch
// Exercise 4.2

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <list>
#include <string>

void print(const std::list<std::string>& lst)
{
  for (std::list<std::string>::const_iterator i = lst.begin();
       i != lst.end(); ++i)
    std::cout << *i << " ";
}

int main()
{
  // Print empty list
  std::list<std::string> mylist;

  // Add 5 elements
  mylist.push_back("eggs");
  mylist.push_back("milk");
  mylist.push_back("sugar");
  mylist.push_back("chocolate");
  mylist.push_back("flour");
  std::cout << "After adding 5 items: ";
  print(mylist);
  std::cout << std::endl;

  // Remove first element
  mylist.pop_front();
  std::cout << "Removing first element: ";
  print(mylist);
  std::cout << std::endl;

  // Add "coffee"
  mylist.push_front("coffee");
  std::cout << "After prepending \"coffee\": ";
  print(mylist);
  std::cout << std::endl;

  // Replace "sugar" with "honey"
  std::list<std::string>::iterator i;
  for (i = mylist.begin(); i != mylist.end(); ++i)
    if (*i == "sugar")
      *i = "honey";
  std::cout << "After replacing \"sugar\" with \"honey\": ";
  print(mylist);
  std::cout << std::endl;

  // Insert "baking powder" before "milk" 
  for (i = mylist.begin(); i != mylist.end(); ++i)
  {
    if (*i == "milk")
    {
      mylist.insert(i, "baking powder");
      break;
    }
  }
  std::cout << "After inserting \"baking powder\": ";
  print(mylist);
  std::cout << std::endl;

  return 0;
}