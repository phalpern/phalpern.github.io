// The C++ Standard Library From Scratch
// Exercise 5.2

#include <iostream>
#include <string>
#include <cstring>

#ifndef _MSC_VER
using std::strlen;
#endif

int main()
{
  std::string theString = "Congratualations Mrs. <name>, you and Mr. <name> \n"
    "are the lucky recipients of a trip for two to XXXXXX. \n"
    "Your trip to XXX is already scheduled";

  // Replace "<name>" with "Luzer":
  std::string::size_type namepos = theString.find("<name>");
  while (namepos != std::string::npos)
  {
    theString.replace(namepos, strlen("<name>"), "Luzer");
    namepos += strlen("Luzer");  // Advance past end of substitution
    namepos = theString.find("<name>", namepos);  // Find next "<name>"
  }

  // Replace sequences of 'X' with "Siberia"
  std::string::size_type xpos = theString.find_first_of('X');
  while (xpos != std::string::npos)
  {
    // Find end of string of X's
    std::string::size_type xend = theString.find_first_not_of('X', xpos);

    // Replace X's with "Siberia"
    theString.replace(xpos, xend - xpos, "Siberia");
    xend += strlen("Siberia"); // Advance past end of substitution
    xpos = theString.find("X");
  }

  std::string::size_type luckpos = theString.find("luck");
  if (luckpos != std::string::npos)
    theString.insert(luckpos, "un");

  theString.append(" for December");
  // Alternative: theString += " for December";

  std::cout << theString << std::endl;

  return 0;
}