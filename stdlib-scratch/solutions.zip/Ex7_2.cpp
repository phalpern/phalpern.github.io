// The C++ Standard Library From Scratch
// Exercise 7.2

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <iomanip>
#include <string>
#include <map>

int main()
{
  std::map<int, std::string> toc;

  toc[1] = "Introduction";
  toc[9] = "Chapter 1: Introducing TinyPIM";
  toc[30] = "Chapter 2: Implementing the Address Class with Text String";

  // Alternative insertion syntax:
  toc.insert(std::make_pair(57,
    std::string("Chapter 3: Creating an Address Book using Container Classes")));

  for (std::map<int, std::string>::const_iterator i = toc.begin();
       i != toc.end(); ++i)
    std::cout << std::left << std::setw(60) << std::setfill('.') << i->second 
              << std::right << std::setw(3) << std::setfill(' ') << i->first
              << std::endl;
  
  return 0;
}