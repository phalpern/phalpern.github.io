// The C++ Standard Library From Scratch
// Exercise 7.1

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <deque>

class WindGauge
{
public:
  WindGauge(int period = 12);
  void currentWindSpeed(int speed);
  int high() const;
  int low() const;
  int average() const;
private:
  int			intervals;	// number of intervals to store
  std::deque<int>	history;	// wind speed history
};

/////////////////////// Implementation of class WindGauge //////////////

// Constructor
WindGauge::WindGauge(int period)
  : intervals(period)
{
}

void WindGauge::currentWindSpeed(int speed)
{
  history.push_back(speed);

  if (history.size() > intervals)
    history.pop_front();
}

int WindGauge::high() const
{
  if (history.empty())
    return 0;
  
  int ret = history.front();
  for (int i = 1; i < history.size(); ++i)
    if (history[i] > ret)
      ret = history[i];

  return ret;
}

int WindGauge::low() const
{
  if (history.empty())
    return 0;
  
  int ret = history.front();
  for (int i = 1; i < history.size(); ++i)
    if (history[i] < ret)
      ret = history[i];

  return ret;
}

int WindGauge::average() const
{
  if (history.empty())
    return 0;
  else
  {
    int sum = 0;
    for (int i = 0; i < history.size(); ++i)
      sum += history[i];
    return sum / history.size();
  }
}


///////////////// TEST PROGRAM //////////////////////////////
void dump(const WindGauge& w)
{
  std::cout << "WindSpeed: low = " << w.low()
	    << ", high = " << w.high()
	    << ", average = " << w.average() << std::endl;;
}

int main()
{
  WindGauge w;
  std::cout << "At initialization, ";
  dump(w);

  w.currentWindSpeed(15);
  w.currentWindSpeed(16);
  w.currentWindSpeed(12);
  w.currentWindSpeed(15);
  w.currentWindSpeed(15);
  std::cout << "After adding 5 data points, ";
  dump(w);

  w.currentWindSpeed(16);
  w.currentWindSpeed(17);
  w.currentWindSpeed(16);
  w.currentWindSpeed(16);
  w.currentWindSpeed(20);
  w.currentWindSpeed(17);
  w.currentWindSpeed(16);
  w.currentWindSpeed(15);
  w.currentWindSpeed(16);
  w.currentWindSpeed(20);
  std::cout << "After adding 10 more data points, ";
  dump(w);

  return 0;
}
