// The C++ Standard Library From Scratch
// Exercise 6.4

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <map>

class Access
{
public:
  void activate(unsigned code, unsigned level);
  void deactivate(unsigned code);
  bool isactive(unsigned code, unsigned level) const;
private:
  std::map<unsigned, unsigned>	active_codes;
};

////////////////// Implementation of Access /////////////////////////
void Access::activate(unsigned code, unsigned level)
{
  // Add or replace access level for given code
  active_codes[code] = level;
}

void Access::deactivate(unsigned code)
{
  active_codes.erase(code);
}

bool Access::isactive(unsigned code, unsigned level) const
{
  if (active_codes.count(code) == 0)
    return false;
  else
  {
    // Because operator[]() does not work for const maps (since it might
    // insert an element if not already there), we must cast away const.
    std::map<unsigned, unsigned>& activity_codes_ =
#ifdef NO_CONST_CAST
      (map<unsigned, unsigned>&)active_codes;
#else
      const_cast<std::map<unsigned, unsigned>&>(active_codes);
#endif
    return activity_codes_[code] >= level;
  }
}

///////////// Test program /////////////////////////

int main()
{
  Access lock;

  lock.activate(1234, 1);
  lock.activate(9999, 5);
  lock.activate(9876, 9);

  unsigned code;
  unsigned door_level = 5;
  
  std::cout << "Door access level = " << door_level << std::endl;
  std::cout << "Enter code: ";
  std::cin >> code;
  while (std::cin && ! lock.isactive(code, door_level))
  {
    std::cout << "Code rejected, door locked" << std::endl;
    std::cout << "Enter code: ";
    std::cin >> code;
  }

  if (std::cin)
    std::cout << "Code accepted, door open" << std::endl;

  lock.deactivate(code);
  lock.activate(9999, 8);	// Raise access for 9999
  lock.activate(1111, 7);

  door_level = 7;
  std::cout << "\nDoor access level = " << door_level << std::endl;
  std::cout << "Enter code: ";
  std::cin >> code;
  while (std::cin && ! lock.isactive(code, door_level))
  {
    std::cout << "Code rejected, door locked" << std::endl;
    std::cout << "Enter code: ";
    std::cin >> code;
  }

  if (std::cin)
    std::cout << "Code accepted, door open" << std::endl;

  return 0;
}
