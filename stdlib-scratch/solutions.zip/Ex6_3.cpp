// The C++ Standard Library From Scratch
// Exercise 6.3

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <set>

class Access
{
public:
  void activate(unsigned code);
  void deactivate(unsigned code);
  bool isactive(unsigned code) const;
private:
  std::set<unsigned>	active_codes;
};

////////////////// Implementation of Access /////////////////////////
void Access::activate(unsigned code)
{
  active_codes.insert(code);
}

void Access::deactivate(unsigned code)
{
  active_codes.erase(code);
}

bool Access::isactive(unsigned code) const
{
  return active_codes.count(code) != 0;
}

///////////// Test program /////////////////////////

int main()
{
  Access lock;

  lock.activate(1234);
  lock.activate(9999);
  lock.activate(9876);

  unsigned code;
  std::cout << "Enter code: ";
  std::cin >> code;
  while (std::cin && ! lock.isactive(code))
  {
    std::cout << "Code rejected, door locked" << std::endl;
    std::cout << "Enter code: ";
    std::cin >> code;
  }

  if (lock.isactive(code))
    std::cout << "Code accepted, door open" << std::endl;

  lock.deactivate(code);
  lock.deactivate(9999);
  lock.activate(1111);

  std::cout << "Enter code: ";
  std::cin >> code;
  while (std::cin && ! lock.isactive(code))
  {
    std::cout << "Code rejected, door locked" << std::endl;
    std::cout << "Enter code: ";
    std::cin >> code;
  }

  if (lock.isactive(code))
    std::cout << "Code accepted, door open" << std::endl;

  return 0;
}
