// The C++ Standard Library From Scratch
// Exercise 3.1

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <vector>
#include <string>

void print(const std::vector<std::string>& v)
{
  for (int i = 0; i < v.size(); ++i)
    std::cout << v[i] << " ";
}

int main()
{
  // Print empty vector
  std::vector<std::string> myvector;
  std::cout << "Empty vector: ";
  print(myvector);
  std::cout << std::endl;

  // Add 5 elements
  myvector.push_back("eggs");
  myvector.push_back("milk");
  myvector.push_back("sugar");
  myvector.push_back("chocolate");
  myvector.push_back("flour");
  std::cout << "After adding 5 items: ";
  print(myvector);
  std::cout << std::endl;

  // Add "coffee"
  myvector.push_back("coffee");
  std::cout << "After adding \"coffee\": ";
  print(myvector);
  std::cout << std::endl;

  // Replace "sugar" with "honey"
  int i;
  for (i = 0; i < myvector.size(); ++i)
    if (myvector[i] == "sugar")
      myvector[i] = "honey";
  std::cout << "After replacing \"sugar\" with \"honey\": ";
  print(myvector);
  std::cout << std::endl;

  // Save a copy of myvector before modifying it
  std::vector<std::string> save(myvector);

  // Remove "milk" from a copy of myvector (alters order of elements)
  for (i = 0; i < myvector.size(); ++i)
  {
    if (myvector[i] == "milk")
    {
      // Move last element to current position
      myvector[i] = myvector.back();
      // Remove last element
      myvector.pop_back();
      break;
    }
  }
  std::cout << "After removing \"milk\": ";
  print(myvector);
  std::cout << std::endl;

  // Restore myvector from the saved copy
  myvector = save;

  // Remove "milk" from a copy of myvector, preserving order of elements.
  for (i = 0; i < myvector.size(); ++i)
  {
    if (myvector[i] == "milk")
    {
      // Move elements after "milk" up one position
      for ( ; i + 1 < myvector.size(); ++i)
        myvector[i] = myvector[i + 1];

      // Remove spare alement at the end
      myvector.pop_back();
      break;
    }
  }
  std::cout << "After order-preserving removal of \"milk\": ";
  print(myvector);
  std::cout << std::endl;

  return 0;
}