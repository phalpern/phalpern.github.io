// The C++ Standard Library From Scratch
// Exercise 5.1

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <list>
#include <string>

void print(const std::list<std::string>& lst)
{
  for (std::list<std::string>::const_iterator i = lst.begin();
       i != lst.end(); ++i)
    std::cout << *i << " ";
}

int main()
{
  // Create empty list
  std::list<std::string> mylist;

  while (std::cin.good())
  {
    std::string item;
    std::cout << "Enter item: ";
    std::getline(std::cin, item);
    if (std::cin.fail())
      break;
    else if (item == "done")
      break;
    else
      mylist.push_back(item);
  }

  std::cout << "Shopping list: ";
  print(mylist);
  std::cout << std::endl;

  return 0;
}