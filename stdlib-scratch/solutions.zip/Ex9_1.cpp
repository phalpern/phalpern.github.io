// The C++ Standard Library From Scratch
// Exercise 9.1

#include <iostream>
#include <iomanip>
#include <sstream>

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

class point
{
public:
  point() : x_(0.0), y_(0.0) { }
  point(double x, double y) : x_(x), y_(y) { }
  double x() const { return x_; }
  double y() const { return y_; }
private:
  double x_, y_;
};

std::istream& operator>>(std::istream& is, point& p)
{
  char paren = '\0', comma = '\0';
  double x, y;

  if (! is.good())
    return is;

  const std::ios::iostate errorflag = std::ios::failbit;
  try 
  {
    is >> paren;
    if (is.fail() || paren != '(') throw errorflag;
    is >> x >> comma;
    if (is.fail() || comma != ',') throw errorflag;
    is >> y >> paren;
    if (is.fail() || paren != ')') throw errorflag;
  }
  catch (std::ios::iostate flag)
  {
    // Catch error condition and set stream state accordingly
    is.setstate(flag);
    return is;
  }

  // Success
  p = point(x, y);

  return is;
}

std::ostream& operator<<(std::ostream& os, const point& p)
{
  std::stringstream tempstrm;

  // Use floating-point precision and notation flags from os stream.
  std::ios::fmtflags fflags = os.setf(0, std::ios::floatfield);
  int precision = os.precision();
  tempstrm.setf(fflags, std::ios::floatfield);
  tempstrm.precision(precision);

  // Format point into temporary string
  tempstrm << '(' << p.x() << ", " << p.y() << ')';

  // Write temporary string to real stream
  os << tempstrm.str();

  return os;
}

int main()
{
  point p;

  while (std::cin.good())
  {
    std::cout << "Enter point as (x, y): ";
    if (std::cin.peek() == 'q')
      break;  // Quit program

    if (std::cin >> p)
    {
      std::cout << "You entered: **" << std::setfill('*')
                << std::setw(15) << std::left << p << std::endl;
    }
    else if (! std::cin.bad() && ! std::cin.eof())
    {
      std::cin.clear();
      std::cout << "Bad input" << std::endl;
    }
    std::cin.ignore(10000, '\n');
  } // end while

  return 0;
}
