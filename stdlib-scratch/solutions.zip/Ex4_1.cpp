// The C++ Standard Library From Scratch
// Exercise 4.1

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <list>
#include <string>

void print(const std::list<std::string>& lst)
{
  for (std::list<std::string>::const_iterator i = lst.begin();
       i != lst.end(); ++i)
    std::cout << *i << " ";
}

int main()
{
  // Print empty list
  std::list<std::string> mylist;
  std::cout << "Empty list: ";
  print(mylist);
  std::cout << std::endl;

  // Add 5 elements
  mylist.push_back("eggs");
  mylist.push_back("milk");
  mylist.push_back("sugar");
  mylist.push_back("chocolate");
  mylist.push_back("flour");
  std::cout << "After adding 5 items: ";
  print(mylist);
  std::cout << std::endl;

  // Add "coffee"
  mylist.push_back("coffee");
  std::cout << "After adding \"coffee\": ";
  print(mylist);
  std::cout << std::endl;

  // Replace "sugar" with "honey"
  std::list<std::string>::iterator i;
  for (i = mylist.begin(); i != mylist.end(); ++i)
    if (*i == "sugar")
      *i = "honey";
  std::cout << "After replacing \"sugar\" with \"honey\": ";
  print(mylist);
  std::cout << std::endl;

  // Save a copy of mylist before modifying it
  std::list<std::string> save(mylist);

  // Remove "milk" from a copy of mylist (alters order of elements)
  for (i = mylist.begin(); i != mylist.end(); ++i)
  {
    if (*i == "milk")
    {
      // Move last element to current position
      *i = mylist.back();
      // Remove last element
      mylist.pop_back();
      break;
    }
  }
  std::cout << "After removing \"milk\": ";
  print(mylist);
  std::cout << std::endl;

  // Restore mylist from the saved copy
  mylist = save;

  // Remove "milk" from a copy of mylist, preserving order of elements.
  for (i = mylist.begin(); i != mylist.end(); ++i)
  {
    if (*i == "milk")
    {
      mylist.erase(i);
      break;
    }
  }
  std::cout << "After order-preserving removal of \"milk\": ";
  print(mylist);
  std::cout << std::endl;

  return 0;
}