// TinyPIM (c) 1999 Pablo Halpern. File AddressBook.h

#ifndef AddressBook_dot_h
#define AddressBook_dot_h

#include <set>
#include "Address.h"

class AddressBook
{
  // Data structure abbreviations
  typedef std::multiset<Address>		addrByName_t;

public:
  AddressBook();
  ~AddressBook();

  // Exception classes
  class AddressNotFound { };
  class DuplicateId { };

  int insertAddress(const Address& addr, int recordId = 0) 
    throw (DuplicateId);
  void eraseAddress(int recordId) throw (AddressNotFound);
  void replaceAddress(const Address& addr, int recordId = 0)
    throw (AddressNotFound);
  const Address& getAddress(int recordId) const 
    throw (AddressNotFound);

  // Return number of records found with specified name.
  int countName(const std::string& lastname,
                const std::string& firstname) const;

  // Iterator to traverse address records
  typedef addrByName_t::const_iterator const_iterator;

  // Functions to traverse all address records
  const_iterator begin() const { return addresses_.begin(); }
  const_iterator end()   const { return addresses_.end();   }

  // Find first Address with name greater-than-or-equal to specified 
  // name. Usually, this will be a name that starts with the 
  // specified strings.
  const_iterator findNameStartsWith(const std::string& lastname,
                              const std::string& firstname="") const;

  // Find next Address in which any field contains the specified
  // string. Indicate starting point for search with start parameter.
  const_iterator findNextContains(const std::string& searchStr,
                                  const_iterator start) const;

  // Return iterator to specified records ID.
  const_iterator findRecordId(int recordId) const
    throw (AddressNotFound);

private:
  // Disable copying
  AddressBook(const AddressBook&);
  AddressBook& operator=(const AddressBook&);

  static int nextId_;

  addrByName_t addresses_;

  // Get the index of the record with the specified ID.
  addrByName_t::iterator getById(int recordId)
    throw (AddressNotFound);
  addrByName_t::const_iterator getById(int recordId) const
    throw (AddressNotFound);
};

#endif // AddressBook_dot_h
