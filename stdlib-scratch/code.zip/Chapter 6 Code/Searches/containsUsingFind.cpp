#include <algorithm>

// Return true if at least one record is found with specified name.
bool AddressBook::containsName(const std::string& lastname,
                               const std::string& firstname) const
{
  Address searchAddr;
  searchAddr.lastname(lastname);
  searchAddr.firstname(firstname);

  // Find position of first match in addresses_
  addrlist::const_iterator srch = std::find(addresses_.begin(), 
                                            addresses_.end(), searchAddr);

  // Return true if found, false if not.
  return (srch != addresses_.end());
}
