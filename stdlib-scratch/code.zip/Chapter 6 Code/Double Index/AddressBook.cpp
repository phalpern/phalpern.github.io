// TinyPIM (c) 1999 Pablo Halpern. File AddressBook.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <algorithm>

#include "AddressBook.h"

int AddressBook::nextId_ = 1;

AddressBook::AddressBook()
{
}

AddressBook::~AddressBook()
{
}

int AddressBook::insertAddress(const Address& addr, 
                               int recordId) throw (DuplicateId)
{
  if (recordId == 0)
    // If recordId is not specified, create a new record id.
    recordId = nextId_++;
  else if (recordId >= nextId_)
    // Make sure nextId is always higher than any known record id.
    nextId_ = recordId + 1;
  else if (addrById_.count(recordId))
    // recordId is already in map
    throw DuplicateId();

  // Assign recordId to copy of Address
  Address addrCopy(addr);
  addrCopy.recordId(recordId);

  // Insert record into set
  addrByName_t::iterator i = addresses_.insert(addrCopy);

  // Insert Address iterator into id-based map
  // addrById_.insert(std::make_pair(recordId, i));
  addrById_[recordId] = i;

  return recordId;
}

AddressBook::addrByName_t::iterator 
AddressBook::getById(int recordId) throw (AddressNotFound)
{
  // Find record by Id.
  addrById_t::iterator idIter = addrById_.find(recordId);
  if (idIter == addrById_.end())
    throw AddressNotFound();

  return idIter->second;
}

AddressBook::addrByName_t::const_iterator 
AddressBook::getById(int recordId) const throw (AddressNotFound)
{
  // Find record by Id.
  addrById_t::const_iterator idIter = addrById_.find(recordId);
  if (idIter == addrById_.end())
    throw AddressNotFound();

  return idIter->second;
}

void AddressBook::eraseAddress(int recordId) 
  throw (AddressNotFound)
{
  addrByName_t::iterator i = getById(recordId);

  // Remove entry from both containers
  addresses_.erase(i);
  addrById_.erase(recordId);
}

void AddressBook::replaceAddress(const Address& addr, int recordId)
  throw (AddressNotFound)
{
  if (recordId == 0)
    recordId = addr.recordId();

  eraseAddress(recordId);
  insertAddress(addr, recordId);
}

const Address& AddressBook::getAddress(int recordId) const
  throw (AddressNotFound)
{
  return *getById(recordId);
}

// Return number of records found with specified name.
int AddressBook::countName(const std::string& lastname,
                           const std::string& firstname) const
{
  Address searchAddr;
  searchAddr.lastname(lastname);
  searchAddr.firstname(firstname);

  // Return a count of the number of matching records
  return addresses_.count(searchAddr);
}

// Find first Address with name greater-than-or-equal to specified 
// name. Usually, this will be a name that starts with the 
// specified strings.
AddressBook::const_iterator
AddressBook::findNameStartsWith(const std::string& lastname,
                                const std::string& firstname) const
{
  Address searchAddr;
  searchAddr.lastname(lastname);
  searchAddr.firstname(firstname);

  return addresses_.lower_bound(searchAddr);
}

// Function object class to search for a string within an Address.
class AddressContainsStr : public std::unary_function<Address, bool>
{
public:
  AddressContainsStr(const std::string& str) : str_(str) { }

  bool operator()(const Address& a)
  {
    using std::string;

    // Return true if any Address field contains str_
    return (a.lastname().find(str_) != string::npos ||
            a.firstname().find(str_) != string::npos ||
            a.phone().find(str_) != string::npos ||
            a.address().find(str_) != string::npos);
  }

private:
  std::string str_;
};

// Find next Address in which any field contains the specified
// string. Indicate starting point for search with start parameter.
AddressBook::const_iterator 
AddressBook::findNextContains(const std::string& searchStr,
                              const_iterator start) const
{
  return std::find_if(start, addresses_.end(), 
                      AddressContainsStr(searchStr));
}

// Return iterator to specified records ID.
AddressBook::const_iterator 
AddressBook::findRecordId(int recordId) const throw (AddressNotFound)
{
  return getById(recordId);
}
