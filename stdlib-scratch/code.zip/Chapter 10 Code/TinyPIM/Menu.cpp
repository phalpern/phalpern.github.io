// TinyPIM (c) 1999 Pablo Halpern. File Menu.cpp

#include <cctype>
#include <iostream>

#if ! (_MSC_VER || __GNUC__)
using std::tolower;
using std::toupper;
#endif

#include "Menu.h"

// Display a menu string and then allow user to enter
// a character from within a string of choices. If user enteres
// a character not in the choices string, an error is printed and
// the user is prompted to try again. After a valid character is
// entered, the selected character is returned. In case of an
// I/O error, '\0' is returned. Comparisons are not case sensitive.
char Menu::getMenuSelection(const std::string& menu,
			    const std::string& choices)
{
  while (std::cin.good())
  {
    std::cout << menu;

    char selection = '\0';
    std::cin >> selection;
    if (std::cin.fail())
      break;

      // Throw away rest of input line
    std::cin.ignore(10000, '\n');

    // Search for selection in either uppercase or lowercase
    if (choices.find(toupper(selection)) != std::string::npos ||
        choices.find(tolower(selection)) != std::string::npos)
      return toupper(selection);	  // Valid entry
    else
      std::cout << "Invalid selection, please try again.\n\n";
  } // end while

  return '\0';
}

// Clear the screen
void Menu::clearScreen()
{
  // Because not all terminals respond to the formfeed character to
  // clear the screen, we also output 25 newlines:
  std::cout << "\f\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
            << std::flush;
}

// Define menuStack_ static member variable
std::stack<Menu*> Menu::menuStack_;

