// TinyPIM (c) 1999 Pablo Halpern. File TinyPIM.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <cstdlib>

#ifndef _MSC_VER
using std::exit;
#endif

#include "PIMData.h"
#include "AddressBookMenu.h"
#include "DateBookMenu.h"
#include "MainMenu.h"

// Test function to generate addresses (in TestAddrData.cpp)
extern void generateAddresses(AddressBook& addrbook, 
                              int numAddresses);

// Test function to generate appointments (in TestAddrData.cpp)
extern void generateAppointments(DateBook& dateBook, int numDays);

// Global data object
PIMData myPIMData;

int main()
{
  try 
  {
    // Create address book and date book
    std::auto_ptr<AddressBook> addrBookPtr(new AddressBook);
    std::auto_ptr<DateBook>    dateBookPtr(new DateBook);

    // Will only get here if no exception was thrown
    myPIMData.addressBook(addrBookPtr);
    myPIMData.dateBook(dateBookPtr);
  }
  catch (...)
  {
    std::cerr << "Could not create address and date books.\n";
    exit(EXIT_FAILURE);
  }

#ifndef NOGENERATE
  // Generate 50 random address-book entries
  generateAddresses(myPIMData.addressBook(), 50);

  // Generate a year's worth of appointments
  generateAppointments(myPIMData.dateBook(), 366);
#endif

  // Create address book menu and date book menus
  AddressBookMenu addrBookMenu(myPIMData.addressBook());
  DateBookMenuCatalog dateBookMenus(myPIMData.dateBook());

  // Create the main menu and push it on the menu stack
  MainMenu mainMenu(&addrBookMenu, dateBookMenus.monthlyMenu());
  Menu::enterMenu(&mainMenu);

  // Process menu choices until menu exits.
  while (Menu::isActive())
    Menu::activeMenu()->mainLoop();

  std::cout << "\nThank you for using TinyPIM!\n" << std::endl;

  return 0;
}