// TinyPIM (c) 1999 Pablo Halpern. File DateBook.h

#ifndef DateBook_dot_h
#define DateBook_dot_h 1

#include <set>
#include <map>

#include "Appointment.h"

class DateBook
{
  // Data structure abbreviations
  typedef std::multiset<Appointment>            apptByTime_t;
  typedef std::map<int, apptByTime_t::iterator> apptById_t;

public:
  DateBook();
  ~DateBook();

  // Exception classes
  class appointmentNotFound { };
  class DuplicateId { };

  int insertAppointment(const Appointment& appt, int recordId = 0) 
    throw (DuplicateId);
  void eraseAppointment(int recordId) throw (appointmentNotFound);
  void replaceAppointment(const Appointment& appt, int recordId = 0)
    throw (appointmentNotFound);
  const Appointment& getAppointment(int recordId) const 
    throw (appointmentNotFound);

  // Iterator to traverse Appointment records
  typedef apptByTime_t::const_iterator const_iterator;

  // Functions to traverse all Appointment records
  const_iterator begin() const { return appointments_.begin(); }
  const_iterator end()   const { return appointments_.end();   }

  // Find first Appointment with start time greater-than-or-equal to 
  // specified time.
  const_iterator findAppointmentAtTime(const DateTime& dt) const;

  // Find next Appointment in which any field contains the specified
  // string. Indicate starting point for search with start parameter.
  const_iterator findNextContains(const std::string& searchStr,
                                  const_iterator start) const;

  // Return iterator to specified records ID.
  const_iterator findRecordId(int recordId) const
    throw (appointmentNotFound);

private:
  // Disable copying
  DateBook(const DateBook&);
  DateBook& operator=(const DateBook&);

  static int nextId_;

  apptByTime_t appointments_;
  apptById_t   apptById_;

  // Get the index of the record with the specified ID.
  apptByTime_t::iterator getById(int recordId)
    throw (appointmentNotFound);
  apptByTime_t::const_iterator getById(int recordId) const
    throw (appointmentNotFound);
};


#endif // DateBook_dot_h
