// TinyPIM (c) 1999, Pablo Halpern. File DisplayList.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <cassert>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <iterator>

#ifdef _MSC_VER
#define min _cpp_min
#define max _cpp_max
#endif

#include "DisplayList.h"

// Constructor sets screen size.
DisplayList::DisplayList(int linesPerScreen)
  : linesPerScreen_(linesPerScreen)
{
  reset();
}

// Destructor doesn't have to do much.
DisplayList::~DisplayList() { }

// Clear all data
void DisplayList::reset()
{
  cache_.clear();
  cachedFirst_ = false;
  cachedLast_ = false;
  firstVisibleIdx_ = 0;
}

// Fill cache in the forward direction.
// Specify start index and number of desired records. If not
// enough records are available, will set cachedLast_.
void DisplayList::fillCacheFwd(int start, int numNeeded)
{
  int startId = 0;
  if (cache_.empty())
    // Start caching from beginning of list
    cachedFirst_ = true;
  else
  {
    // Start retrieving from last item in cache
    assert(start < cache_.size());
    startId = cache_.back();
  }

  int recordsTillEnd = cache_.size() - start;
  if (! cachedLast_ && recordsTillEnd < numNeeded)
  {
    // Too few entries in cache to fill screen. Need to fetch more.

    std::vector<int> moreRecords;
    cachedLast_ = fetchMore(startId, numNeeded - recordsTillEnd,
                            moreRecords);

    std::copy(moreRecords.begin(), moreRecords.end(), 
              std::back_inserter(cache_));
  }
}

// Fill cache in the backward direction.
// Specify start index and number of desired records. If not
// enough records are available, will set cachedLast_.
void DisplayList::fillCacheBkwd(int start, int numNeeded)
{
  int startId = 0;
  if (cache_.empty())
    // Start caching from end of list
    cachedLast_ = true;
  else
  {
    // Start retrieving from first item in cache
    assert(start < cache_.size());
    startId = cache_.front();
  }

  int recordsTillStart = start;
  if (! cachedFirst_ && recordsTillStart < numNeeded)
  {
    // Too few entries in cache to fill screen. Need to fetch more.

    std::vector<int> moreRecords;
    cachedFirst_ = fetchMore(startId,
                             -(numNeeded - recordsTillStart),
                             moreRecords);

    std::copy(moreRecords.rbegin(), moreRecords.rend(), 
              std::front_inserter(cache_));

    // We inserted records before the first visible one.
    // We must update firstVisibleIdx_ to reflect its new position.
    firstVisibleIdx_ += moreRecords.size();
  }
}

void DisplayList::display()
{
  // Make sure cache contains a screenful of records
  fillCacheFwd(firstVisibleIdx_, linesPerScreen_);

  // If after attempting to fill cache, it is still empty, then
  // there are no records to display.
  if (cache_.empty())
  {
    // Display empty-list marker.
    std::cout << "============= No records selected ==============="
              << std::endl;
    return;
  }

  // Calculate the number of records to display.
  // It is the smaller of the number of lines in a screenful or the
  // number of records left at the end of the cache.
  int recsToShow = std::min(linesPerScreen_, 
                            int(cache_.size() - firstVisibleIdx_));

  if (atStart())
    // Display start-of-list marker.
    std::cout << "=============== Start of list ===============\n";

  std::deque<int>::iterator start = cache_.begin()+ firstVisibleIdx_;
  std::deque<int>::iterator finish = start + recsToShow;
  for (std::deque<int>::iterator i = start; i != finish; ++i)
  {
    // Display line number
    int lineNum = i - start + 1;  // Start counting at 1
    std::cout << std::setw(2) << std::setfill(' ')
              << std::right << std::dec << lineNum << ": ";
    displayRecord(*i);
    std::cout << std::endl;
  }

  if (atEnd())
    // Display end-of-list marker.
    std::cout << "=============== End of list ===============";

  std::cout << std::endl;
}

void DisplayList::pageDown()
{
  // Scroll current bottom-of-screen line to top of screen
  if (atEnd())
    return;

  // Cache current screenful and next screenful
  fillCacheFwd(firstVisibleIdx_, 2 * linesPerScreen_);

  // Advance visible index one screenful, but only if there exists
  // at least one screenful past the current firstVisibleIdx_.
  if (! atEnd())
    firstVisibleIdx_ += linesPerScreen_;
}

void DisplayList::pageUp()
{
  // Scroll current top-of-screen line to bottom of screen
  if (atStart())
    return;

  // Cache previous screenful
  fillCacheBkwd(firstVisibleIdx_, linesPerScreen_);

  // Advance visible index backward one screenful, but not past
  // start of cache.
  firstVisibleIdx_ = std::max(firstVisibleIdx_ - linesPerScreen_, 0);
}

void DisplayList::toStart()
{
  if (cachedFirst_)
    firstVisibleIdx_ = 0;
  else
    // Cached records do not include top of cache.
    reset();
}

bool DisplayList::atStart()
{
  return cachedFirst_ && (firstVisibleIdx_ == 0);
}

bool DisplayList::atEnd()
{
  return (cachedLast_ &&  
          (cache_.size() - firstVisibleIdx_ <= linesPerScreen_));
}

// Scroll so that specified record is at the top of the screen.
void DisplayList::scrollToTop(int recordId)
{
  assert(recordId != 0);

  // Find specified record in cache:
  cache_t::iterator found = std::find(cache_.begin(), cache_.end(),
                                      recordId);

  // If didn't find record in cache, flush cache and start reloading.
  if (found == cache_.end())
  {
    reset();
    cache_.push_back(recordId);
    firstVisibleIdx_ = 0;
  }
  else
    firstVisibleIdx_ = found - cache_.begin();

  fillCacheFwd(firstVisibleIdx_, linesPerScreen_);
}

// Return ID of nth record on screen
int DisplayList::screenRecord(int n) const
{
  if (firstVisibleIdx_ + n >= cache_.size())
    return 0;
  else
    return cache_[firstVisibleIdx_ + n];
}

// Ask the user for a record number and convert to a recordId
int DisplayList::selectRecord()
{
  while (std::cin.good())
  {
    int maxSelection = std::min(int(cache_.size()- firstVisibleIdx_),
                                linesPerScreen_);

    if (maxSelection <= 0)
    {
      std::cout << "No records to select\n";
      return 0;
    }

    // Prompt for record number in visible range
    std::cout << "Choose a record number between "
  	      << 1 << " and " << maxSelection
	      << "\nRecord number (0 to cancel)? ";

    unsigned selection = 0;

    std::cin >> selection;
    if (std::cin.fail())
    {
      if (std::cin.bad() || std::cin.eof())
        break;

      // Recoverable input error. (User typed a non-numeric input).
      // Clear error condition and throw away rest of input line
      // then continue loop.
      std::cin.clear();
      std::cin.ignore(10000, '\n');
      std::cout << "Invalid selection, please try again.\n\n";
      continue;
    } // end else

    // Throw away rest of input line
    std::cin.ignore(10000, '\n');

    if (selection == 0)
      return 0;

    // Make sure user chose one of the visible records.
    if (1 <= selection && selection <= maxSelection)
      return cache_[firstVisibleIdx_ + selection - 1];
    else
      std::cout << "Invalid selection, please try again.\n\n";

  } // end while

  return 0;
}
