// TinyPIM (c) 1999 Pablo Halpern. File DisplayList.h

#ifndef DisplayList_dot_h
#define DisplayList_dot_h 1

#include <deque>
#include <vector>

// This abstract class is used to display a list of records
// where the specific record type being displayed is 
// determined by the derived classes.
// If there are more records in the list than can fit on
// a screen, a partial list is displayed and functions
// are provided for scrolling up and down in the list.
class DisplayList
{
public:
  DisplayList(int linesPerScreen = 15);
  virtual ~DisplayList();

  void display();   // Display the list
  void pageDown();  // Scroll down one screenful
  void pageUp();    // Scroll up one screenful
  void toStart();   // Scroll to the first screenful
  bool atStart();   // True if displaying first screenful
  bool atEnd();     // True if displaying last screenful
  void reset();     // Reinitialize (discard cached records)
  int screenRecord(int n) const; // Return ID of nth record on screen

  // Scroll so that specified record is at the top of the screen.
  void scrollToTop(int recordId);

  // Ask the user for a record number and return selected recordId
  // Returns 0 if no record selected (e.g. user aborted).
  int selectRecord();

protected:
  // Derived classes define displayRecord to display a
  // particular record type.
  virtual void displayRecord(int recordId) = 0;

  // Derived classes define fetchMore to get numRecords more records
  // starting at, but not including startId. result is vector of
  // record IDs. If numRecords is negative, then retrieve -numRecords
  // records BEFORE startId. If startId is zero, then return the 
  // first (or last) records. Result may have more records than 
  // requested. Returns true if the last (or first) record is in
  // result.
  virtual bool fetchMore(int startId, int numRecords,
                         std::vector<int>& result) = 0;

private:

  typedef std::deque<int> cache_t;    // Type of record Id cache

  int     linesPerScreen_;  // Number of lines per screenful
  cache_t cache_;           // Cache of known record IDs.
  bool    cachedFirst_;     // true if cache_ contains first record
  bool    cachedLast_;      // true if cache_ contains last record
  int     firstVisibleIdx_; // Deque index of first visible record

  // Fill cache in the forward direction.
  // Specify start index and number of desired records. If not
  // enough records are available, will set cachedLast_.
  void fillCacheFwd(int start, int numNeeded);

  // Fill cache in the backward direction.
  // Specify start index and number of desired records. If not
  // enough records are available, will set cachedLast_.
  void fillCacheBkwd(int start, int numNeeded);
};

#endif // DisplayList_dot_h