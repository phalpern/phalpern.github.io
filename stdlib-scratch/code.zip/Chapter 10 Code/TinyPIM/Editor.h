// TinyPIM (c) 1999 Pablo Halpern

#ifndef Editor_dot_h
#define Editor_dot_h 1

#include <string>

// Editor base class.
// Provides basic functionality for single- and multi-line editing.
class Editor
{
public:
  enum editStatus { 
    normal,   // Edit is proceeding normally
    finished, // User has indicated that editing is complete.
    canceled  // User has indicated that editing should be canceled.
  };

  Editor() : status_(normal) { }

  // Edit a single line of text. The prompt and initial value are
  // passed in.  This function modifies the value and returns true if
  // edit status is normal or false if editing is finished or
  // canceled.  The following inputs have special meaning:
  //
  //	[CR]  Pressing [ENTER] will leave value unchanged.
  //	.     A period by itself signals that editing is complete.
  //	!x    signals that editing should be canceled.
  bool editSingleLine(const std::string& prompt, std::string& value);

  // Edit a multi-line string. The prompt for all lines and an
  // initial multi-line value are passed in. The edited string is
  // stored back in value.  Within the edit session, each line is
  // edited separately.  This function modifies the value and returns
  // true if edit status is normal or false if editing is finished or
  // canceled.  The following inputs have special meaning:
  //
  //	[CR]  Pressing [ENTER] without entering any text will
  //	      leave the current line unchanged and advance to the
  //	      next line. 
  //	.     A period by itself signals that editing is complete.
  //	!x    signals that editing should be canceled.
  //	!n    Editing this field is complete. Caller should advance
  //	      to next field (status remains normal).
  //	!i    Insert a new line before the current one.
  //	!d    Delete the current line.
  bool editMultiLine(const std::string& prompt, std::string& value);

  // Return the status of the edit.
  editStatus status() const { return status_; }

private:
  editStatus status_;
};

#endif // Editor_dot_h
