// TinyPIM (c) 1999 Pablo Halpern. File AddressDisplayList.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <iomanip>
#include <algorithm>
#include "AddressDisplayList.h"
#include "Address.h"
#include "AddressBook.h"

// Construct with a reference to the address book
AddressDisplayList::AddressDisplayList(AddressBook& addrBook)
  : addressBook_(addrBook)
{
}

// Display the specified address record in one-line format
void AddressDisplayList::displayRecord(int recordId)
{
  Address record = addressBook_.getAddress(recordId);

  // Create a name string in "lastname, firstname" format.
  std::string name = record.lastname();
  if (! record.firstname().empty())
    name.append(", ").append(record.firstname());

  // Output name and phone number on one line (two columns).
  std::cout << std::setfill('.') << std::setw(40) 
            << std::left << name << record.phone();
}

// Fetch more records from AddressBook
bool AddressDisplayList::fetchMore(int startId, int numRecords, 
                                   std::vector<int>& result)
{
  // Remove old contents of result
  result.clear();

  if (numRecords == 0)
    return false;

  bool forwards = true;
  if (numRecords < 0)
  {
    forwards = false;
    numRecords = -numRecords;
  }

  // Check for empty list
  if (addressBook_.begin() == addressBook_.end())
    return true;

  // Declare an iterator
  AddressBook::const_iterator iter;

  // Get iterator to record specified by startId.
  // When fetching forward, increment iterator past matching record
  // to avoid a duplicate insertion into the display list.
  if (startId == 0)
    iter = (forwards ? addressBook_.begin() : addressBook_.end());
  else
  {
    iter = addressBook_.findRecordId(startId);
    if (forwards)
      ++iter;
  }

  if (containsString_.empty())
  {
    // "List all" mode

    if (forwards)
    {
      // retrieve records starting at iter
      while (iter != addressBook_.end() && numRecords-- > 0)
        result.push_back((iter++)->recordId());

      // Return true if reached end of the list
      return iter == addressBook_.end();
    }
    else
    {
      // retrieve records starting at one before iter
      while (iter != addressBook_.begin() && numRecords-- > 0)
        result.push_back((--iter)->recordId());

      // Records were pushed backwards, reverse them here:
      std::reverse(result.begin(), result.end());

      // Return true if reached front of the list
      return iter == addressBook_.begin();
    }
  }
  else
  {
    // "Contains string" mode

    if (forwards)
    {
      // Retrieve records AFTER startId

      // Find matching record starting at iter
      iter = addressBook_.findNextContains(containsString_, iter);
      while (iter != addressBook_.end() && numRecords-- > 0)
      {
        result.push_back(iter->recordId());

        // Find next matching record
        iter = addressBook_.findNextContains(containsString_,++iter);
      }

      // Return true if we reached the end
      return iter == addressBook_.end();
    }
    else
    {
      // retrieve records BEFORE startId

      // AddressBook does not a function to search backwards.
      // Instead, we retrieve ALL records before iter
      AddressBook::const_iterator endIter = iter;
      iter = addressBook_.findNextContains(containsString_, 
                                           addressBook_.begin());
      while (*iter < *endIter) // Empty loop if *endIter not found
      {
        result.push_back(iter->recordId());
        iter = addressBook_.findNextContains(containsString_,++iter);
      }

      return true;  // Yes, we reached the start of the list.
    }
  }
}

// Scroll to first Address with name greater-than-or-equal to 
// specified name. Usually, this will be a name that starts with
// the specified strings. Returns false if no match found.
bool
AddressDisplayList::findNameStartsWith(const std::string& lastname, 
                                       const std::string& firstname)
{
  containsString_ = ""; // Turn off "contains string" mode

  reset();
  AddressBook::const_iterator iter 
    = addressBook_.findNameStartsWith(lastname, firstname);

  if (iter == addressBook_.end())
    return false;

  // Scroll found record to top
  scrollToTop(iter->recordId());
  return true;
}

// List only those records that contain the specified string
void AddressDisplayList::listContainsString(const std::string& s)
{
  if (containsString_ == s)
    return;

  reset();
  containsString_ = s;

  // Next call to display() will cause search
}

// List all records (use after a listContainsString)
void AddressDisplayList::listAll()
{
  listContainsString("");
  toStart();
}
