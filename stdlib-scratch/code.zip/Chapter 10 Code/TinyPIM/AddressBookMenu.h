// TinyPIM (c) 1999 Pablo Halpern

#ifndef AddressBookMenu_dot_h
#define AddressBookMenu_dot_h 1

#include "Menu.h"
#include "AddressDisplayList.h"

class AddressBookMenu : public Menu
{
public:
  AddressBookMenu(AddressBook& addrBook)
    : addressBook_(addrBook), displayList_(addrBook) { }

  void mainLoop();

private:
  void viewEntry();
  void createEntry();
  void editEntry();
  void deleteEntry();
  void listAll();
  void lookup();
  void search();

  AddressBook&	      addressBook_;
  AddressDisplayList  displayList_;
};

#endif // AddressBookMenu_dot_h