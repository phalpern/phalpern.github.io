// TinyPIM (c) 1999 Pablo Halpern

#ifndef AddressEditor_dot_h
#define AddressEditor_dot_h 1

#include "Editor.h"
#include "Address.h"

// Class for editing an Address object.
class AddressEditor : public Editor
{
public:
  // Start with an empty Address object
  AddressEditor();

  // Edit an existing Address object
  AddressEditor(const Address& a);

  // Use compiler-generated destructor
  // ~AddressEditor();

  // Main loop returns true if address was successfully edited,
  // false if edit was aborted.
  bool edit();

  // This accessor is used to retrieve the modified address.
  Address addr() const { return addr_; }

  // This accessor is used to set the Address object to edit:
  void addr(const Address& a) { addr_ = a; }

private:
  // Disable copying
  AddressEditor(const AddressEditor&);
  const AddressEditor& operator=(const AddressEditor&);

  // Member variables
  Address   addr_;

protected:
  // Protected functions
  bool editPhone(const std::string& prompt, std::string& phone);
};

#endif // AddressEditor_dot_h
