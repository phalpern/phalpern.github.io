// TinyPIM (c) 1999 Pablo Halpern. File DateBookMenu.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#pragma warning(disable : 4355)
#endif

#include <iostream>
#include <iomanip>
#include <sstream>
#include <climits>
#include "DateBookMenu.h"
#include "Appointment.h"
#include "DateBook.h"
#include "AppointmentEditor.h"

void DateBookMenu::setDate(DateTime dt)
{
  currDate_ = dt;
  reset();
}

void DateBookMenu::reset()
{
}

void DateBookMenu::createEntry()
{
  // Edit an empty appointment
  Appointment appt;
  appt.startTime(currDate_);
  appt.endTime(currDate_);
  AppointmentEditor	editor(appt);

  // Continue editing until a record is saved or canceled.
  while (editor.edit())
  {
    appt = editor.appt();
    if (appt.description().empty())
    {
      std::cout << "Description must not be empty." << std::endl;
      continue;	  // Loop and re-edit
    }
 
    // insert record.
    dateBook_.insertAppointment(appt);
    setDate(appt.startTime());
    reset();
    break;
  } // end while
}

void DateBookMenu::showDay()
{
  // Go to daily mode for the current date
  exitMenu();
  catalog_->dailyMenu()->setDate(currDate_);
  enterMenu(catalog_->dailyMenu());
}

void DateBookMenu::showWeek()
{
  // Go to weekly mode for the current date
  exitMenu();
  catalog_->weeklyMenu()->setDate(currDate_);
  enterMenu(catalog_->weeklyMenu());
}

void DateBookMenu::showMonth()
{
  // Go to monthly mode for the current date
  exitMenu();
  catalog_->monthlyMenu()->setDate(currDate_);
  enterMenu(catalog_->monthlyMenu());
}

void DateBookMenu::search()
{
  std::string searchString;
  std::cout << "Search for string: ";
  std::getline(std::cin, searchString);

  // If no search string entered, abort.
  if (std::cin.fail() || searchString.empty())
    return;

  // Set both search string and date
  exitMenu();
  catalog_->stringSearchMenu()->searchString(searchString);
  catalog_->stringSearchMenu()->setDate(currDate_);
  enterMenu(catalog_->stringSearchMenu());
}

void DateBookMenu::gotoDate()
{
  std::string dateString;
  while (std::cin.good())
  {
    std::cout << "Goto date [" << currDate_.dateStr() << "]: ";
    std::getline(std::cin, dateString);
    if (dateString.empty())
      break;
    else if (dateString[0] == 't' || dateString[0] == 'T')
    {
      // User entered "today"
      setDate(DateTime::now());
      break;
    }

    // Set date value
    DateTime newdate;
    if (! newdate.dateStr(dateString))
      std::cout << "Invalid date, please try again\n";
    else
    {
      setDate(newdate);
      break;
    } // end if
  } // end while
}



void ListBasedDateBookMenu::reset()
{
  displayList_.reset();
  displayList_.currDate(currDate_);
}

void ListBasedDateBookMenu::viewEntry()
{
  int recordId = displayList_.selectRecord();
  if (recordId <= 0)
    return;

  setDate(dateBook_.getAppointment(recordId).startTime());

  Appointment appt = dateBook_.getAppointment(recordId);
  std::cout << "Date: " << appt.startTime().dateStr() << '\n';
  std::cout << "From " << appt.startTime().timeStr()
            << " to " << appt.endTime().timeStr() << '\n';
  std::cout << appt.description();

  std::cout << "\n\nPress [RETURN] when ready.";
  std::cin.ignore(INT_MAX, '\n');
}

void ListBasedDateBookMenu::deleteEntry()
{
  int recordId = displayList_.selectRecord();
  if (recordId <= 0)
    return;

  setDate(dateBook_.getAppointment(recordId).startTime());
  
  // Erase the appointment
  dateBook_.eraseAppointment(recordId);

  // Deleting the entry invalidates the display list cache. 
  // Reset it, then scroll back to the previous position
  displayList_.reset();
}

void ListBasedDateBookMenu::editEntry()
{
  int recordId = displayList_.selectRecord();
  if (recordId <= 0)
    return;

  // Create an editor for the selected appointment
  Appointment appt = dateBook_.getAppointment(recordId);
  AppointmentEditor editor(appt);

  // Edit the appointment
  if (editor.edit())
  {
    // Replace appointment with modified version.
    dateBook_.replaceAppointment(editor.appt());

    // Appointment's sort order might have changed. We need to reset
    // the display list.
    displayList_.reset();
    setDate(editor.appt().startTime());
  }
}

void MonthlyDateBookMenu::mainLoop()
{
  clearScreen();
  int year, month, day;
  currDate_.getDate(year, month, day);
  std::cout << "*** Appointment Book ***\n"
            << "Month of " << currDate_.monthName() << ' ' << year
            << "\n\n";

  displayMonth();
  std::cout << '\n';

  const char menu[] =
    "(P)revious month, (N)ext month, (C)reate, (S)earch,\n"
    "(R)edisplay, d(A)ily view, (W)eekly view, (G)oto date, "
    "(Q)uit ? ";
  const char choices[] = "PNCSRAWGQ";

  switch (getMenuSelection(menu, choices))
  {
  case 'P': showPrevious();             break;
  case 'N': showNext();                 break;
  case 'C': createEntry();              break;
  case 'S': search();                   break;
  case 'R': /* do nothing, just loop */ break;
  case 'A': showDay();                  break;
  case 'W': showWeek();                 break;
  case 'G': gotoDate();                 break;
  case 'Q': exitMenu();                 break;
  default:  exitMenu();                 break;
  }
}

void MonthlyDateBookMenu::reset()
{
  cacheGood_ = false;
}

void MonthlyDateBookMenu::displayMonth()
{
  using namespace std::rel_ops;

  // Calculate start of current month and next month
  DateTime startOfMonth = currDate_.startOfMonth();
  DateTime nextMonth = startOfMonth.addDay(31).startOfMonth();
  int year, month, day;

  if (! cacheGood_)
  {
    // Clear the scoreboard
    for (int i = 0; i < 32; ++i)
      scoreBoard_[i] = false;

    // Iterate through every entry within the month
    DateBook::const_iterator iter = 
      dateBook_.findAppointmentAtTime(startOfMonth);
    DateBook::const_iterator endIter = 
      dateBook_.findAppointmentAtTime(nextMonth);

    // For each entry, set the scoreboard value for that day to true.
    for ( ; iter != endIter; ++iter)
    {
      iter->startTime().getDate(year, month, day);
      scoreBoard_[day] = true;
    }
  }

  // Calculate the day of the week for the first day of the month.
  int startWday = startOfMonth.dayOfWeek();

  // Calculate last day of the month (== day zero of next month)
  nextMonth.addDay(-1).getDate(year, month, day);
  int monthLen = day;

  std::cout << " ";
  int wday = 0;

  // Print blank spaces for first few days of first week of month.
  for ( ; wday < startWday; ++wday)
    std::cout << "    ";

  // Print each day of month
  std::cout.fill(' ');
  std::cout.setf(std::ios::dec, std::ios::basefield);
  std::cout.setf(std::ios::right, std::ios::adjustfield);
  for (int mday = 1; mday <= monthLen; ++mday)
  {
    if (wday == 0 && mday != 1)
      std::cout << "\n ";
    std::cout << std::setw(3) << mday 
              << (scoreBoard_[mday] ? '*' : ' ');
    wday = (wday + 1) % 7;
  }
  std::cout << std::endl;
}

void MonthlyDateBookMenu::showPrevious()
{
  // Subtract one month
  int year, month, day, hour, min;
  currDate_.get(year, month, day, hour, min);
  setDate(DateTime(year, month - 1, day, hour, min));
}

void MonthlyDateBookMenu::showNext()
{
  // Add one month
  int year, month, day, hour, min;
  currDate_.get(year, month, day, hour, min);
  setDate(DateTime(year, month + 1, day, hour, min));
}

WeeklyDateBookMenu::WeeklyDateBookMenu(DateBook& datebook,
                                       DateBookMenuCatalog* catalog)
  : ListBasedDateBookMenu(datebook, catalog)
{
  displayList_.listWeek(DateTime::now());
}

void WeeklyDateBookMenu::mainLoop()
{
  clearScreen();
  std::cout << "*** Appointment Book ***\n"
            << "Week of " 
            << currDate_.startOfWeek().dateStr() << " to "
            << currDate_.startOfWeek().addDay(6).dateStr()
            << "\n\n";

  displayList_.display();
  std::cout << '\n';

  const char menu[] = "(P)revious week, (N)ext week,\n"
      "scroll (B)ackward, scroll (F)orward, (V)iew, \n"
      "(C)reate, (D)elete, (E)dit, (S)earch, (R)edisplay,\n"
      "d(A)ily view, (M)onthly view, (G)oto date, (Q)uit ? ";
  const char choices[] = "PNBFVCDESRAMGQ";

  switch (getMenuSelection(menu, choices))
  {
  case 'P': showPrevious();             break;
  case 'N': showNext();                 break;
  case 'B': displayList_.pageUp();      break;
  case 'F': displayList_.pageDown();    break;
  case 'V': viewEntry();                break;
  case 'C': createEntry();              break;
  case 'D': deleteEntry();              break;
  case 'E': editEntry();                break;
  case 'S': search();                   break;
  case 'R': /* do nothing, just loop */ break;
  case 'A': showDay();                  break;
  case 'M': showMonth();                break;
  case 'G': gotoDate();                 break;
  case 'Q': exitMenu();                 break;
  default:  exitMenu();                 break;
  }
}

void WeeklyDateBookMenu::showPrevious()
{
  setDate(currDate_.addDay(-7));
}

void WeeklyDateBookMenu::showNext()
{
  setDate(currDate_.addDay(7));
}

DailyDateBookMenu::DailyDateBookMenu(DateBook& datebook,
                                     DateBookMenuCatalog* catalog)
  : ListBasedDateBookMenu(datebook, catalog)
{
  displayList_.listDay(DateTime::now());
}

void DailyDateBookMenu::mainLoop()
{
  clearScreen();
  std::cout << "*** Appointment Book ***\n"
            << currDate_.wdayName() << ' ' << currDate_.dateStr()
            << "\n\n";

  displayList_.display();
  std::cout << '\n';

  const char menu[] = "(P)revious day, (N)ext day,\n"
      "scroll (B)ackward, scroll (F)orward, (V)iew, \n"
      "(C)reate, (D)elete, (E)dit, (S)earch, (R)edisplay,\n"
      "(W)eekly view, (M)onthly view, (G)oto date, (Q)uit ? ";
  const char choices[] = "PNBFVCDESRWMGQ";

  switch (getMenuSelection(menu, choices))
  {
  case 'P': showPrevious();             break;
  case 'N': showNext();                 break;
  case 'B': displayList_.pageUp();      break;
  case 'F': displayList_.pageDown();    break;
  case 'V': viewEntry();                break;
  case 'C': createEntry();              break;
  case 'D': deleteEntry();              break;
  case 'E': editEntry();                break;
  case 'S': search();                   break;
  case 'R': /* do nothing, just loop */ break;
  case 'W': showWeek();                 break;
  case 'M': showMonth();                break;
  case 'G': gotoDate();                 break;
  case 'Q': exitMenu();                 break;
  default:  exitMenu();                 break;
  }
}

void DailyDateBookMenu::showPrevious()
{
  setDate(currDate_.addDay(-1));
}

void DailyDateBookMenu::showNext()
{
  setDate(currDate_.addDay(1));
}

StringSearchDateBookMenu::StringSearchDateBookMenu(DateBook& db,
                                        DateBookMenuCatalog *catalog)
  : ListBasedDateBookMenu(db, catalog)
{
  displayList_.listContainsString("");
}

void StringSearchDateBookMenu::mainLoop()
{
  clearScreen();
  std::cout << "*** Appointment Book ***\n"
            << "Records matching \"" << searchString_  << "\"\n\n";

  displayList_.display();
  std::cout << '\n';

  const char menu[] =
      "scroll (B)ackward, scroll (F)orward, (V)iew, \n"
      "(C)reate, (D)elete, (E)dit, (S)earch, (R)edisplay,\n"
      "d(A)ily view, (W)eekly view, (M)onthly view, (G)oto date, "
      "(Q)uit ? ";
  const char choices[] = "BFVCDESRAWMGQ";

  switch (getMenuSelection(menu, choices))
  {
  case 'B': displayList_.pageUp();      break;
  case 'F': displayList_.pageDown();    break;
  case 'V': viewEntry();                break;
  case 'C': createEntry();              break;
  case 'D': deleteEntry();              break;
  case 'E': editEntry();                break;
  case 'S': search();                   break;
  case 'R': /* do nothing, just loop */ break;
  case 'A': showDay();                  break;
  case 'W': showWeek();                 break;
  case 'M': showMonth();                break;
  case 'G': gotoDate(); showDay();      break;
  case 'Q': exitMenu();                 break;
  default:  exitMenu();                 break;
  }
}

void StringSearchDateBookMenu::searchString(const std::string& s)
{
  searchString_ = s;
  displayList_.listContainsString(s);
}

DateBookMenuCatalog::DateBookMenuCatalog(DateBook& dateBook)
  : dailyMenu_(new DailyDateBookMenu(dateBook, this)),
    weeklyMenu_(new WeeklyDateBookMenu(dateBook, this)),
    monthlyMenu_(new MonthlyDateBookMenu(dateBook, this)),
    stringSearchMenu_(new StringSearchDateBookMenu(dateBook, this))
{
}

DailyDateBookMenu* DateBookMenuCatalog::dailyMenu()
{
  return dailyMenu_.get();
}

WeeklyDateBookMenu* DateBookMenuCatalog::weeklyMenu()
{
  return weeklyMenu_.get();
}

MonthlyDateBookMenu* DateBookMenuCatalog::monthlyMenu()
{
  return monthlyMenu_.get();
}

StringSearchDateBookMenu* DateBookMenuCatalog::stringSearchMenu()
{
  return stringSearchMenu_.get();
}
