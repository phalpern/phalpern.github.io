// TinyPIM (c) 1999 Pablo Halpern. File Appointment.h

#ifndef Appointment_dot_h
#define Appointment_dot_h 1

#include <string>
#include "DateTime.h"

class Appointment
{
public:
  Appointment() : recordId_(0) { }

  // Field accessors
  int recordId() const { return recordId_; }
  void recordId(int i) { recordId_ = i; }

  DateTime startTime() const { return startTime_; }
  void startTime(const DateTime& dt);

  DateTime endTime() const { return endTime_; }
  void endTime(const DateTime& dt);

  std::string description() const { return description_; }
  void description(const std::string& s);

private:
  int         recordId_;
  DateTime    startTime_;
  DateTime    endTime_;
  std::string description_;
};

inline bool operator< (const Appointment& a1, const Appointment& a2)
  { return a1.startTime() < a2.startTime(); }

#endif //  Appointment_dot_h
