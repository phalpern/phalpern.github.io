// TinyPIM (c) 1999 Pablo Halpern. File PIMData.h

#ifndef PIMData_dot_h
#define PIMData_dot_h 1

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <memory>
#include "AddressBook.h"
#include "DateBook.h"

// Class to encapsulate all of the data for a given PIM file.
class PIMData
{
public:
  PIMData() { }
  AddressBook& addressBook() { return *addressBook_; }
  DateBook& dateBook() { return *dateBook_; }

  void addressBook(std::auto_ptr<AddressBook> ab) 
    { addressBook_ = ab; }
  void dateBook(std::auto_ptr<DateBook> db) { dateBook_ = db; }

private:
  std::auto_ptr<AddressBook>    addressBook_;
  std::auto_ptr<DateBook>       dateBook_;

  // Because this class contains auto_ptrs, it does not have proper 
  // copy semantics. We disable copying to avoid problems.
  PIMData(const PIMData&);
  PIMData& operator=(const PIMData&);
};

#endif // PIMData_dot_h
