// TinyPIM (c) 1999 Pablo Halpern. File DateTime.cpp

#include <iomanip>
#include <sstream>
#include "DateTime.h"

#ifndef _MSC_VER
using std::mktime;
using std::localtime;
using std::time_t;
using std::strftime;
#endif 

DateTime::DateTime(int year, int month, int day, int hour, int min)
{
  set(year, month, day, hour, min);
}

void DateTime::get(int& year, int& month, int& day,
                   int& hour, int& min) const
{
  std::tm* mytm = localtime(&theTime_);
  year  = mytm->tm_year + 1900;
  month = mytm->tm_mon + 1;
  day   = mytm->tm_mday;
  hour  = mytm->tm_hour;
  min   = mytm->tm_min;
}

void DateTime::getDate(int& year, int& month, int& day) const
{
  int hour, min;
  get(year, month, day, hour, min);
}

void DateTime::getTime(int& hour, int& min) const
{
  int year, month, day;
  get(year, month, day, hour, min);
}

// Return the day of the week (range 0 = Sunday to 6 = Saturday)
int DateTime::dayOfWeek() const
{
  return localtime(&theTime_)->tm_wday;
}

DateTime& DateTime::set(int year, int month, int day, 
                        int hour, int min)
{
  // Years from 0 - 49 are assumed to mean 2000 - 2049.
  // Years 1900 or over are assumed to be 4-digit years.
  // Other years are assumed to mean 1950 - 1999.
  if (year < 50)
    year += 2000;
  else if (year < 1900)
    year += 1900;

  std::tm mytm;
  mytm.tm_year = year - 1900;
  mytm.tm_mon  = month - 1; // zero based
  mytm.tm_mday = day;
  mytm.tm_hour = hour;
  mytm.tm_min  = min;
  mytm.tm_sec  = 0;
  mytm.tm_isdst = -1;

  theTime_ = mktime(&mytm);

  return *this;
}

DateTime& DateTime::setDate(int year, int month, int day)
{
  int hour, min;
  getTime(hour, min);
  set(year, month, day, hour, min);

  return *this;
}

DateTime& DateTime::setTime(int hour, int min)
{
  int year, month, day;
  getDate(year, month, day);
  set(year, month, day, hour, min);

  return *this;
}

std::string DateTime::dateStr() const
{
  char buf[20];
  strftime(buf, 20, "%x", localtime(&theTime_));
  return buf;
}

std::string DateTime::timeStr() const
{
  char buf[20];
  strftime(buf, 20, "%I:%M%p", localtime(&theTime_));
  return buf;
}

// Name of day of the week
std::string DateTime::wdayName() const
{
  char buf[30];
  strftime(buf, 30, "%A", localtime(&theTime_));
  return buf;
}

// Name of month of the year
std::string DateTime::monthName() const
{
  char buf[30];
  strftime(buf, 30, "%B", localtime(&theTime_));
  return buf;
}

bool DateTime::dateStr(const std::string& s)
{
  char slash1, slash2;
  int mon, day, year;

  // Unpack the date part using a stringstream
  std::istringstream tmpstrm(s);
  tmpstrm >> mon >> slash1 >> day >> slash2 >> year;

  // Check for error in date
  if (tmpstrm.fail() || slash1 != '/' || slash2 != '/' ||
      mon < 1 || 12 < mon || day < 1 || 31 < day)
    return false;

  setDate(year, mon, day);
  return true;
}

bool DateTime::timeStr(const std::string& s)
{
  char colon;
  int hour, min;
  char ampm[3];

  std::istringstream tmpstrm(s);
  tmpstrm >> hour >> colon >> min;

  // Check for error in time
  if (tmpstrm.fail() || hour < 0 || 23 < hour || min < 0 || 59 < min)
    return false;

  // Check for am/pm indicator
  tmpstrm >> std::setw(3) >> ampm;
  bool useAmPm = ! tmpstrm.fail();

  // Convert hour from 12-hour to 24-hour format (0-23)
  if (useAmPm)
  {
    if (hour == 12)
      hour = 0;
    if (ampm[0] == 'p' || ampm[0] == 'P')
      hour += 12;
  }

  setTime(hour, min);
  return true;
}

// Return this day at midnight
DateTime DateTime::startOfDay() const
{
  std::tm theTm = *localtime(&theTime_);
  theTm.tm_hour = 0;
  theTm.tm_min = 0;
  theTm.tm_sec = 0;
  theTm.tm_isdst = -1;

  DateTime result;
  result.theTime_ = mktime(&theTm);
  return result;
}

// Return most recent Sunday at midnight
DateTime DateTime::startOfWeek() const
{
  std::tm theTm = *localtime(&theTime_);
  theTm.tm_mday -= theTm.tm_wday;   // Subtract current day-of week
  theTm.tm_hour = 0;
  theTm.tm_min = 0;
  theTm.tm_sec = 0;
  theTm.tm_isdst = -1;

  DateTime result;
  result.theTime_ = mktime(&theTm);
  return result;
}

// Return first day of this month
DateTime DateTime::startOfMonth() const
{
  std::tm theTm = *localtime(&theTime_);
  theTm.tm_mday = 1;
  theTm.tm_hour = 0;
  theTm.tm_min = 0;
  theTm.tm_sec = 0;
  theTm.tm_isdst = -1;

  DateTime result;
  result.theTime_ = mktime(&theTm);
  return result;
}

// Add a certain number of days to the date
DateTime DateTime::addDay(int days) const
{
  std::tm theTm = *localtime(&theTime_);
  theTm.tm_mday += days;
  theTm.tm_isdst = -1;

  DateTime result;
  result.theTime_ = mktime(&theTm);
  return result;
}

// Get the current date and time
DateTime DateTime::now()
{
  DateTime ret;
  ret.theTime_ = time(0);  // Call std::time
  return ret;
}

std::ostream& operator<<(std::ostream& os, const DateTime& dt)
{
  return os << (dt.dateStr() + " " + dt.timeStr());
}

std::istream& operator>>(std::istream& is, DateTime& dt)
{
  DateTime result;

  // First, read the date part
  std::string date;
  is >> date;
  if (is.fail())
    return is;  // I/O error

  if (! result.dateStr(date))
  {
    is.clear(std::ios::failbit);
    return is;  // Format error
  }

  std::string time;
  is >> time;
  if (is.fail())
    return is;  // I/O error

  if (! result.timeStr(time))
  {
    is.clear(std::ios::failbit);
    return is;  // Format error
  }

  dt = result;
  return is;
}

