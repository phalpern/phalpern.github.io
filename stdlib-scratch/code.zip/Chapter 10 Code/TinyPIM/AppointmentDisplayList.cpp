// TinyPIM (c) 1999 Pablo Halpern. File AppointmentDisplayList.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <iomanip>
#include <algorithm>
#include "AppointmentDisplayList.h"
#include "Appointment.h"
#include "DateBook.h"

#ifdef _MSC_VER
#define min _cpp_min
#define max _cpp_max
#endif

// Construct with a reference to the appointment book
AppointmentDisplayList::AppointmentDisplayList(DateBook& apptBook)
  : dateBook_(apptBook), mode_(dayMode), currDate_(DateTime::now())
{
}

// Display the specified appointment record in one-line format
void AppointmentDisplayList::displayRecord(int recordId)
{
  if (recordId < 0)
  {
    // A negative recordId means a special date marker in the
    // range -1 (Sunday) to -7 (Saturday).
    // Print the date marker.
    DateTime startOfWeek = currDate_.addDay(-currDate_.dayOfWeek());
    DateTime marker = startOfWeek.addDay(-recordId - 1);
    std::cout << marker.wdayName() << ' ' << marker.dateStr();
    return;
  }

  Appointment record = dateBook_.getAppointment(recordId);

  // Print prefix for entry.
  switch (mode_)
  {
  case dayMode:             
    break;
  case weekMode:    
    // For week mode, indent each entry
    std::cout << "    ";
    break;
  case stringMode:  
    // For string search view, put date on every line.
    std::cout << record.startTime().dateStr() << " ";
    break;
  }

  // format start and end time
  std::cout << record.startTime().timeStr()
            << " - " << record.endTime().timeStr();

  // Output 45 characters of the description or up to the first
  // newline, whichever is shorter.
  int outlen = std::min(45, (int) record.description().find('\n'));
  std::cout << "  " << record.description().substr(0, outlen);
}

// Fetch more records from DateBook
bool AppointmentDisplayList::fetchMore(int startId, int numRecords, 
                                       std::vector<int>& result)
{
  // Remove old contents of result
  result.clear();

  if (numRecords == 0)
    return false;

  bool forwards = true;
  if (numRecords < 0)
  {
    forwards = false;
    numRecords = -numRecords;
  }

  // Check for empty list
  if (dateBook_.begin() == dateBook_.end())
    return true;

  // Declare an iterator
  DateBook::const_iterator iter;

  // Get iterator to record specified by startId.
  // When fetching forward, increment iterator past matching record
  // to avoid a duplicate insertion into the display list.
  if (startId == 0)
    iter = (forwards ? dateBook_.begin() : dateBook_.end());
  else
  {
    iter = dateBook_.findRecordId(startId);
    if (forwards)
      ++iter;
  }

  if (mode_ != stringMode)
  {
    // "List week" or "List day" mode
    DateTime firstDate, lastDate;
    if (mode_ == dayMode)
    {
      // Set time range from midnight at start of day to
      // midnight at end of day
      firstDate = currDate_.startOfDay();
      lastDate  = firstDate.addDay();
    }
    else
    {
      // Set time range from midnight on prior Sunday to
      // midnight on following Sunday.
      firstDate = currDate_.startOfDay();
      firstDate = firstDate.addDay(-firstDate.dayOfWeek());
      lastDate  = firstDate.addDay(7);
    }

    // We will always fill the cache completely in one call,
    // so we force an empty cache to start with. We should never
    // actually reach this point unless the cache is already empty,
    // but just in case ...
    if (startId != 0)
      reset();

    DateBook::const_iterator startIter =
      dateBook_.findAppointmentAtTime(firstDate);
    DateBook::const_iterator endIter =
      dateBook_.findAppointmentAtTime(lastDate);

    // retrieve records starting at iter (doesn't matter whether
    // we are searching forwards or backwards because we are always
    // getting a complete set.
    DateTime prevDate;
    for (iter = startIter; iter != endIter; ++iter)
    {
      using namespace std::rel_ops; // To get != operator
      if (mode_ == weekMode && 
          iter->startTime().startOfDay() != prevDate)
      {
        // Start of a new day. Push a negative number for the
        // day of the week in the range -1 (Sunday) to -7 (Sat)
        result.push_back(-iter->startTime().dayOfWeek() - 1);
        prevDate = iter->startTime().startOfDay();
      }
      result.push_back(iter->recordId());
    }

    // Return true because we reached end of the list
    return true;
  }
  else
  {
    // "Contains string" mode

    if (forwards)
    {
      // Retrieve records AFTER startId

      // Find matching record starting at iter
      iter = dateBook_.findNextContains(containsString_, iter);
      while (iter != dateBook_.end() && numRecords-- > 0)
      {
        result.push_back(iter->recordId());

        // Find next matching record
        iter = dateBook_.findNextContains(containsString_,++iter);
      }

      // Return true if we reached the end
      return iter == dateBook_.end();
    }
    else
    {
      // retrieve records BEFORE startId

      // DateBook does not a function to search backwards.
      // Instead, we retrieve ALL records before iter
      DateBook::const_iterator endIter = iter;
      iter = dateBook_.findNextContains(containsString_, 
                                           dateBook_.begin());
      while (iter != endIter)
      {
        result.push_back(iter->recordId());
        iter = dateBook_.findNextContains(containsString_,++iter);
      }

      return true;  // Yes, we reached the start of the list.
    }
  }
}

// Set the current date
void AppointmentDisplayList::currDate(DateTime dt)
{
  if (dt == currDate_)
    return;

  currDate_ = dt;
  reset();

  // Next call to display() will refill cache
}

// List appointments for the day containing the specified DateTime
void AppointmentDisplayList::listDay(DateTime dt)
{
  if (mode_ == dayMode && currDate_ == dt)
    return;

  mode_ = dayMode;
  currDate(dt);
}

// List appointments for the week containing the specified DateTime
void AppointmentDisplayList::listWeek(DateTime dt)
{
  if (mode_ == weekMode && currDate_ == dt)
    return;

  mode_ = weekMode;
  currDate(dt);
}

// List all records that contain the specified string
void AppointmentDisplayList::listContainsString(const std::string& s)
{
  if (mode_ == stringMode && containsString_ == s)
    return;

  containsString_ = s;
  mode_ = stringMode;
  reset();

  // Next call to display() will refill cache
}
