// TinyPIM (c) 1999 Pablo Halpern. File Appointment.cpp

#include "Appointment.h"

void Appointment::startTime(const DateTime& dt)
{
  startTime_ = dt;
}

void Appointment::endTime(const DateTime& dt)
{
  endTime_ = dt;
}

void Appointment::description(const std::string& s)
{
  description_ = s;
}

