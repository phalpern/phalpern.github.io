// TinyPIM (c) 1999 Pablo Halpern. File DateTime.h

#ifndef DateTime_dot_h
#define DateTime_dot_h 1

#include <iostream>
#include <string>
#include <ctime>

#ifdef _MSC_VER
// Make sure these types and functions are in namespace std:
namespace std {
  typedef ::time_t time_t; 
  typedef ::tm tm;
  inline double difftime(time_t t1, time_t t0) 
    { return ::difftime(t1, t0); }
}
#endif

class DateTime
{
public:
  DateTime() : theTime_(0) { }
  DateTime(int year, int month, int day, int hour, int min);

  // Use compiler generated copy constructor, assignment, destructor
  
  // Read accessors
  void get(int& year, int& month, int& day,
           int& hour, int& min) const;
  void getDate(int& year, int& month, int& day) const;
  void getTime(int& hour, int& min) const;

  // Return the day of the week (range 0 = Sunday to 6 = Saturday)
  int dayOfWeek() const;

  // Write accessors
  DateTime& set(int year, int month, int day, int hour, int min);
  DateTime& setDate(int year, int month, int day);
  DateTime& setTime(int hour, int min);

  // Return this day at midnight
  DateTime startOfDay() const;

  // Return most recent Sunday at midnight
  DateTime startOfWeek() const;

  // Return first day of this month
  DateTime startOfMonth() const;

  // Add a certain number of days to the date
  DateTime addDay(int days = 1) const;

  // Return string quantities
  std::string dateStr() const;    // Date in string form
  std::string timeStr() const;    // Time in string form
  std::string wdayName() const;   // Name of day of the week
  std::string monthName() const;  // Name of month of the year

  // Following functions parse the string and set the date or time.
  // They return false on error
  bool dateStr(const std::string&);
  bool timeStr(const std::string&);

  // Get the current date and time
  static DateTime now();

  friend bool operator==(const DateTime& dt1, const DateTime& dt2)
    { return dt1.theTime_ == dt2.theTime_; }

  friend bool operator<(const DateTime& dt1, const DateTime& dt2)
    { return std::difftime(dt1.theTime_, dt2.theTime_) < 0; }

  friend std::ostream& operator<<(std::ostream& os,
                                  const DateTime& dt);
  friend std::istream& operator>>(std::istream& is, DateTime& dt);

private:

  std::time_t theTime_;
};


#endif // DateTime_dot_h
