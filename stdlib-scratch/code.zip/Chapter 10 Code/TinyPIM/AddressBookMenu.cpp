// TinyPIM (c) 1999 Pablo Halpern. File AddressBookMenu.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include <iomanip>
#include <climits>
#include "AddressBookMenu.h"
#include "Address.h"
#include "AddressBook.h"
#include "AddressEditor.h"

void AddressBookMenu::mainLoop()
{
  clearScreen();
  std::cout << "*** Address Book ***\n\n";

  displayList_.display();
  std::cout << '\n';

  static const char menu[] = 
    "(P)revious, (N)ext, (V)iew, (C)reate, (D)elete, (E)dit, \n"
    "list (A)ll, (L)ookup, (S)earch  (R)edisplay  (Q)uit ? ";

  static const char choices[] = "PNVCDEALSRQ";

  switch (getMenuSelection(menu, choices))
  {
  case 'P': displayList_.pageUp();      break;
  case 'N': displayList_.pageDown();    break;
  case 'V': viewEntry();                break;
  case 'C': createEntry();              break;
  case 'D': deleteEntry();              break;
  case 'E': editEntry();                break;
  case 'A': listAll();                  break;
  case 'L': lookup();                   break;
  case 'S': search();                   break;
  case 'R': /* do nothing, just loop */ break;
  case 'Q': exitMenu();                 break;
  default:  exitMenu();                 break;
  }
}

void AddressBookMenu::viewEntry()
{
  int recordId = displayList_.selectRecord();
  if (recordId == 0)
    return;

  Address addr = addressBook_.getAddress(recordId);
  std::cout << "\nName:  " << addr.lastname();
  if (! addr.firstname().empty())
    std::cout << ", " << addr.firstname();
  std::cout << "\nPhone: " << addr.phone();
  std::cout << "\nAddress:\n" << addr.address();

  std::cout << "\n\nPress [RETURN] when ready.";
  std::cin.ignore(INT_MAX, '\n');
}

void AddressBookMenu::createEntry()
{
  // Edit an empty address
  AddressEditor	editor;
  Address addr;

  // Continue editing until a record is saved or canceled.
  while (editor.edit())
  {
    addr = editor.addr();
    if (addr.lastname().empty())
    {
      std::cout << "Last name must not be empty." << std::endl;
      continue;	  // Loop and re-edit
    }
 
    // Search for existing entries with the same name
    int duplicates = addressBook_.countName(addr.lastname(), 
                                            addr.firstname());

    int recordId = 0;
    if (duplicates == 0)
    {
      // No duplicates, just insert record.
      recordId = addressBook_.insertAddress(addr);

      // Scroll to display new record
      displayList_.scrollToTop(recordId);
      return;
    }
    else
    {
      // Duplicate name. Check to see what user wants to do.
      std::cout << "There are already " << duplicates 
                << " records with this name.\n";
      switch (getMenuSelection(
                 "(S)ave as new record, (E)dit record or (C)ancel? ",
                 "SEC"))
      {
      case 'S':	// Save record (create a duplicate)
        recordId = addressBook_.insertAddress(addr);
        displayList_.scrollToTop(recordId);
        return;

      case 'E':	// Edit record again
        continue;   // Loop back and re-edit

      case 'C':	// Cancel or
      default:	// I/O error
        return;   // Return without changing AddressBook
      } // End switch
    } // end else
  } // end while
}

void AddressBookMenu::deleteEntry()
{
  int recordId = displayList_.selectRecord();
  if (recordId == 0)
    return;
  
  // Find first visible record on screen. If it is the record
  // we are erasing, then find second visible record on screen
  int firstVisible = displayList_.screenRecord(0);
  if (firstVisible == recordId)
    firstVisible = displayList_.screenRecord(1);

  // Erase the address
  addressBook_.eraseAddress(recordId);

  // Deleting the entry invalidates the display list cache. 
  // Reset it, then scroll back to the previous position
  displayList_.reset();
  if (firstVisible != 0)
    displayList_.scrollToTop(firstVisible);
}

void AddressBookMenu::editEntry()
{
  int recordId = displayList_.selectRecord();
  if (recordId == 0)
    return;

  // Create an editor for the selected address
  Address addr = addressBook_.getAddress(recordId);
  AddressEditor editor(addr);

  // Edit the address
  if (editor.edit())
  {
    // Replace address with modified version.
    addressBook_.replaceAddress(editor.addr());

    // Address's sort order might have changed. We need to reset
    // the display list.
    displayList_.reset();

    // Scroll modified item to top of screen
    displayList_.scrollToTop(recordId);
  }
}

void AddressBookMenu::lookup()
{
  // Prompt for lastname and (optional) firstname
  std::string lkupname;
  std::cout << "lookup name (lastname [,firstname]): ";
  std::getline(std::cin, lkupname);
  if (lkupname.empty())
    return;

  // Find end of last name and start of first name
  std::string::size_type lastNameEnd = lkupname.find(',');
  std::string::size_type firstNameStart = std::string::npos;
  if (lastNameEnd != std::string::npos)
    firstNameStart = lkupname.find_first_not_of(", \t\f\n\v", 
                                                lastNameEnd);

  if (firstNameStart == std::string::npos)
    // Lookup using last name only
    displayList_.findNameStartsWith(lkupname.substr(0, lastNameEnd));
  else
    displayList_.findNameStartsWith(lkupname.substr(0, lastNameEnd),
                                    lkupname.substr(firstNameStart));
}

void AddressBookMenu::search()
{
  std::string searchString;
  std::cout << "Search for string: ";
  std::getline(std::cin, searchString);
  if (searchString.empty())
    return;

  displayList_.listContainsString(searchString);
}

void AddressBookMenu::listAll()
{
  displayList_.listAll();
}
