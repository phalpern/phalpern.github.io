// TinyPIM (c) 1999 Pablo Halpern. File MainMenu.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>
#include "PIMData.h"
#include "MainMenu.h"
#include "AddressBookMenu.h"
#include "DateBookMenu.h"

void MainMenu::mainLoop()
{
  clearScreen();
  std::cout << "Welcome to TinyPIM!\n\n"
            << "*** Main Menu ***\n\n";

  static const char menu[] = 
    "Please select from the following:\n\n"
    "  (A)ddress Book\n  (D)ate Book\n  (Q)uit\n\n"
    "Enter selection> ";

  switch (getMenuSelection(menu, "ADQ"))
  {
  case 'A': addressBook();      break;
  case 'D': dateBook();         break;
  case 'Q':
  default: quit();              break;
  } // end switch
}

void MainMenu::addressBook()
{
  enterMenu(addrBookMenu_);
}

void MainMenu::dateBook()
{
  enterMenu(dateBookMenu_);
}

void MainMenu::quit()
{
  exitMenu();
}
