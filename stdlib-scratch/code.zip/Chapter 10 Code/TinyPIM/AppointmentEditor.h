// TinyPIM (c) 1999 Pablo Halpern. File AppointmentEditor.h

#ifndef AppointmentEditor_dot_h
#define AppointmentEditor_dot_h 1

#include "Editor.h"
#include "Appointment.h"

// Class for editing an Appointment object.
class AppointmentEditor : public Editor
{
public:
  // Start with an empty Appointment object
  AppointmentEditor();

  // Edit an existing Appointment object
  AppointmentEditor(const Appointment& a);

  // Use compiler-generated destructor
  // ~AppointmentEditor();

  // Main loop returns true if appointment was successfully edited, 
  // false if edit was aborted.
  bool edit();

  // This accessor is used to retrieve the modified appointment.
  Appointment appt() const { return appt_; }

  // This accessor is used to set the Appointment object to edit:
  void appt(const Appointment& a) { appt_ = a; }

private:
  // Disable copying
  AppointmentEditor(const AppointmentEditor&);
  const AppointmentEditor& operator=(const AppointmentEditor&);

  // Member variables
  Appointment   appt_;

protected:
  // Protected functions
  bool editDate(const std::string& prompt, DateTime& dt);
  bool editTime(const std::string& prompt, DateTime& dt);
};

#endif // AppointmentEditor_dot_h
