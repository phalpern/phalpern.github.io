// TinyPIM (c) 1999 Pablo Halpern. File TestData.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <cstdlib>
#include <sstream>
#include <iomanip>

#ifdef _MSC_VER
namespace std { 
  inline int rand() { return ::rand(); }
  inline void srand(unsigned s) { ::srand(s); }
}
#endif

#include "AddressBook.h"
#include "DateBook.h"

#ifndef __GNUC__ // Following code doesn't work on egcs 1.1.2:

// Return a string at random from a constant array of strings
template <class A>
inline const char* randomString(A& stringArray)
{
  int size = sizeof(A) / sizeof(stringArray[0]);
  int index = std::rand() % size;
  return stringArray[index];
}

#else  // __GNUC__ - This code subsitutes for problem code above

inline const char* _randomString(const char* const stringArray[], int size)
{
  int index = std::rand() % size;
  return stringArray[index];
}

#define randomString(a) _randomString(a, sizeof(a) / sizeof(a[0]))

#endif

void generateAddresses(AddressBook& addrbook, int numAddresses)
{
  // Seed the random number generator with a constant so that the
  // same sequence of "random" numbers will be generated every time.
  std::srand(100);

  static const char* const lastnames[] = {
    "Clinton", "Bush", "Reagan", "Carter", "Ford", "Nixon", "Johnson",
    "Kennedy"
  };

  static const char* const firstnames[] = {
    "William", "George", "Ronald", "Jimmy", "Gerald", "Richard",
    "Lyndon", "Jack", "Hillary", "Barbara", "Nancy", "Rosalynn",
    "Betty", "Pat", "Ladybird", "Jackie"
  };

  // The names of trees are used to generate street and town names.
  static const char* const trees[] = {
    "Maple", "Oak", "Willow", "Pine", "Hemlock", "Redwood", "Fir",
    "Holly", "Elm"
  };

  static const char* const streetSuffixes[] = {
    "St.", "Rd.", "Ln.", "Terr.", "Ave."
  };

  static const char* const townSuffixes[] = {
    "ton", "vale", "burg", "ham"
  };

  // State abbreviations, U.S. and its territories.
  // Thanks to the USPS Web page:
  // http://www.usps.gov/cpim/ftp/pubs/201html/addrpack.htm#abbr
  static const char* const states[] = {
    "AL", "AK", "AS", "AZ", "AR", "CA", "CO", "CT", "DE",
    "DC", "FM", "FL", "GA", "GU", "HI", "ID", "IL", "IN",
    "IA", "KS", "KY", "LA", "ME", "MH", "MD", "MA", "MI",
    "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM",
    "NY", "NC", "ND", "MP", "OH", "OK", "OR", "PA", "PR",
    "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "VI",
    "WA", "WV", "WI", "WY"
  };
  
  for (int i = 0; i < numAddresses; ++i)
  {
    Address addr;
    addr.lastname(randomString(lastnames));
    addr.firstname(randomString(firstnames));

    // Construct a phone number by streaming to a stringstream
    std::stringstream phonestream;
    phonestream << '(' << (std::rand() % 800 + 200) << ") "
                << (std::rand() % 800 + 200) << '-'
                << std::setfill('0') << std::setw(4) 
                << (std::rand() % 10000);
    addr.phone(phonestream.str());

    std::stringstream addrstream;
    // Generate number and street.
    addrstream << (std::rand() % 100 + 1) << " "
               << randomString(trees) << " " 
               << randomString(streetSuffixes) << '\n';

    // Generate town name, state, and zip.
    addrstream << randomString(trees) << randomString(townSuffixes)
               << ", " << randomString(states) << " " 
               << std::setfill('0') << std::setw(5) 
               << (std::rand() % 99999 + 1);
    addr.address(addrstream.str());

    addrbook.insertAddress(addr);
  }
}

// Helper function to generate a random appointment
Appointment randomAppointment(DateTime date, int minHour, 
                              int maxHour, int maxDuration,
                              const std::string desc)
{
  // Generate hour in the range minHour to maxHour
  int hour = std::rand() % (maxHour - minHour + 1) + minHour;

  // Generate minute = 0, 15, 30 or 45
  int min = (std::rand() % 4) * 15;

  // Generate duration (hours) in range 1 - maxDuration
  int duration = std::rand() % maxDuration + 1;

  Appointment result;
  date.setTime(hour, min);
  result.startTime(date);
  date.setTime(hour + duration, min);
  result.endTime(date);
  result.description(desc);

  return result;
}

// Generate appointments between startDate and endDate
void generateAppointments(DateBook& dateBook, int numDays)
{
  // Seed the random number generator with a constant so that the
  // same sequence of "random" numbers will be generated every time.
  std::srand(50);

  static const char* const meetingTypes[] = {
    "Meeting", "Review meeting", "Urgent meeting", "Status meeting"
  };

  static const char* const activities[] = {
    "Golf", "Raquetball", "Dancing", "Piano Lesson"
  };

  static const char* const firstnames[] = {
    "William", "George", "Ronald", "Jimmy", "Gerald", "Richard",
    "Lyndon", "Jack", "Hillary", "Barbara", "Nancy", "Rosalynn",
    "Betty", "Pat", "Ladybird", "Jackie"
  };

  // Create appointments an equal number of days before and
  // after today.
  DateTime startDate=DateTime::now().startOfDay().addDay(-numDays/2);
  DateTime endDate = startDate.addDay(numDays);
  std::string desc;
  for (DateTime currDate = startDate; currDate < endDate;
       currDate = currDate.addDay(1))
  {
    // There is a 1 in 4 chance that there is a morning meeting
    // between 8:00 and 10:45am.
    desc = std::string(randomString(meetingTypes)) + " with " +
      randomString(firstnames);
    if (std::rand() % 4 < 1)
      dateBook.insertAppointment(randomAppointment(currDate, 8, 10,
                                                   3, desc));

    // There is a 2 in 11 chance that there there is a lunch date
    desc = std::string("Lunch with ") + randomString(firstnames);
    if (std::rand() % 11 < 2)
      dateBook.insertAppointment(randomAppointment(currDate, 12, 12,
                                                   2, desc));

    // There is a 1 in 6 chance that there is an evening activity
    desc = std::string(randomString(activities)) + " with " +
      randomString(firstnames);
    if (std::rand() % 6 < 1)
      dateBook.insertAppointment(randomAppointment(currDate, 18, 21,
                                                   4, desc));
   }
}
