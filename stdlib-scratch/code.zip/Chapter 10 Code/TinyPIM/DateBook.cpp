// TinyPIM (c) 1999 Pablo Halpern. File DateBook.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <algorithm>
#include "DateBook.h"

int DateBook::nextId_ = 1;

DateBook::DateBook()
{
}

DateBook::~DateBook()
{
}

int DateBook::insertAppointment(const Appointment& appt, 
                                int recordId) throw (DuplicateId)
{
  if (recordId == 0)
    // If recordId is not specified, create a new record id.
    recordId = nextId_++;
  else if (recordId >= nextId_)
    // Make sure nextId is always higher than any known record id.
    nextId_ = recordId + 1;
  else if (apptById_.count(recordId))
    // recordId is already in map
    throw DuplicateId();

  // Assign recordId to copy of Appointment
  Appointment apptCopy(appt);
  apptCopy.recordId(recordId);

  // Insert record into set
  apptByTime_t::iterator i = appointments_.insert(apptCopy);

  // Insert Appointment iterator into id-based map
  // apptById_.insert(std::make_pair(recordId, i));
  apptById_[recordId] = i;

  return recordId;
}

DateBook::apptByTime_t::iterator 
DateBook::getById(int recordId) throw (appointmentNotFound)
{
  // Find record by Id.
  apptById_t::iterator idIter = apptById_.find(recordId);
  if (idIter == apptById_.end())
    throw appointmentNotFound();

  return idIter->second;
}

DateBook::apptByTime_t::const_iterator 
DateBook::getById(int recordId) const throw (appointmentNotFound)
{
  // Find record by Id.
  apptById_t::const_iterator idIter = apptById_.find(recordId);
  if (idIter == apptById_.end())
    throw appointmentNotFound();

  return idIter->second;
}

void DateBook::eraseAppointment(int recordId) 
  throw (appointmentNotFound)
{
  apptByTime_t::iterator i = getById(recordId);

  // Remove entry from both containers
  appointments_.erase(i);
  apptById_.erase(recordId);
}

void DateBook::replaceAppointment(const Appointment& appt, 
                                  int recordId)
  throw (appointmentNotFound)
{
  if (recordId == 0)
    recordId = appt.recordId();

  eraseAppointment(recordId);
  insertAppointment(appt, recordId);
}

const Appointment& DateBook::getAppointment(int recordId) const
  throw (appointmentNotFound)
{
  return *getById(recordId);
}

// Find first Appointment with start time greater-than-or-equal to 
// specified time.
DateBook::const_iterator 
DateBook::findAppointmentAtTime(const DateTime& dt) const
{
  Appointment searchAppt;
  searchAppt.startTime(dt);

  return appointments_.lower_bound(searchAppt);
}

// Function object class to search for a string within an Appointment
class AppointmentContainsStr 
  : public std::unary_function<Appointment, bool>
{
public:
  AppointmentContainsStr(const std::string& str) : str_(str) { }

  bool operator()(const Appointment& a)
  {
    // Return true if any Appointment field contains str_
    return (a.description().find(str_) != std::string::npos);
  }

private:
  std::string str_;
};

// Find next Appointment in which any field contains the specified
// string. Indicate starting point for search with start parameter.
DateBook::const_iterator 
DateBook::findNextContains(const std::string& searchStr,
                           const_iterator start) const
{
  return std::find_if(start, appointments_.end(), 
                      AppointmentContainsStr(searchStr));
}

// Return iterator to specified records ID.
DateBook::const_iterator 
DateBook::findRecordId(int recordId) const
  throw (appointmentNotFound)
{
  return getById(recordId);
}
