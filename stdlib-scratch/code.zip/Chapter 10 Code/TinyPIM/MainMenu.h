// TinyPIM (c) 1999 Pablo Halpern. File MainMenu.h

#ifndef MainMenu_dot_h
#define MainMenu_dot_h 1

#include "Menu.h"

class MainMenu : public Menu
{
public:
  MainMenu(Menu* addrBookMenu,
           Menu* dateBookMenu) 
    : addrBookMenu_(addrBookMenu), dateBookMenu_(dateBookMenu) { }

  void mainLoop();

private:
  void addressBook();
  void dateBook();
  void quit();

  Menu*  addrBookMenu_;
  Menu*  dateBookMenu_;
};

#endif // MainMenu_dot_h
