// TinyPIM (c) 1999 Pablo Halpern. File Menu.h

#ifndef Menu_dot_h
#define Menu_dot_h 1

#include <string>
#include <stack>

// Base class for menus
class Menu
{
public:
  Menu() { }

  virtual ~Menu() { }

  // Execute the menu's main loop
  virtual void mainLoop() = 0;

  // Return the (global) currently active menu.
  static Menu* activeMenu() { return menuStack_.top(); }

  // Enter a menu or submenu
  static void enterMenu(Menu* m) { menuStack_.push(m); }

  // Exit submenu back to previous-level menu.
  static void exitMenu() { menuStack_.pop(); }

  // Return true if there is an active menu
  static bool isActive() { return ! menuStack_.empty(); }

protected:
  // Utilities for use by derived classes:

  // Display a menu string and then allow user to enter
  // a character from within a string of choices. If user enteres
  // a character not in the choices string, an error is printed and
  // the user is prompted to try again. After a valid character is
  // entered, the selected character is returned. In case of an
  // I/O error, '\0' is returned. Comparisons are not case sensitive
  // and returned letters are always upper-case.
  static char getMenuSelection(const std::string& menu,
                               const std::string& choices);

  // Clears the screen
  static void clearScreen();

private:
  // Stack of menus and submenus.
  static std::stack<Menu*> menuStack_;
};

#endif // Menu_dot_h
