// Simple test of stringstream implementation

#include <iostream>
#include <sstream>

int main()
{
  std::stringstream sstrm;

  sstrm << "Hello world";
  std::cout << "Output: " << sstrm.str() << std::endl;

  std::string h, w;
  sstrm >> h >> w;
  std::cout << "Input: " << h << " " << w << std::endl;

  sstrm.clear();

  sstrm.seekp(-10, std::ios::cur);
  sstrm << "Planet ";
  std::cout << "Seek and output: " << sstrm.str() << std::endl;

  sstrm.seekg(-9, std::ios::end);
  sstrm >> h >> w;
  std::cout << "Seek and input: " << h << " " << w << std::endl;
}
