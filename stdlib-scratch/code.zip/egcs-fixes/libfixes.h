// Pablo Halpern, 1999
// Permision is granted to use, modify and redistribute freely.

// Combined fixes file for a number of deficiencies in the egcs 1.1.2
// compiler's implementation of the standard library. This file
// can be included without modifying source code by specifying the
// --include option to the compiler.

#ifndef libfixes_dot_h
#define libfixes_dot_h 1

#include "iomanipfixes.h"	// Missing iomanipulators (left, right, etc.)
#include "stringiofixes.h"	// String output formatting fix
#include "auto_ptr.h"		// auto_ptr implementation
#include "rel_ops.h"		// rel_ops implementation

#endif /* libfixes_dot_h */
