// TinyPIM (c) 1999 Pablo Halpern. File AddressBook.h

#ifndef AddressBook_dot_h
#define AddressBook_dot_h

#include <vector>
#include "Address.h"

class AddressBook
{
public:
  AddressBook();
  ~AddressBook();

  // Exception classes
  class AddressNotFound { };
  class DuplicateId { };

  int insertAddress(const Address& addr, int recordId = 0) 
    throw (DuplicateId);
  void eraseAddress(int recordId) throw (AddressNotFound);
  void replaceAddress(const Address& addr, int recordId = 0)
    throw (AddressNotFound);
  const Address& getAddress(int recordId) const 
    throw (AddressNotFound);

  // Test routine to print out contents of address book
  void print() const;

private:
  // Disable copying
  AddressBook(const AddressBook&);
  AddressBook& operator=(const AddressBook&);

  static int nextId_;
  std::vector<Address> addresses_;

  // Get the index of the record with the specified ID.
  // Returns notFound if not found.
  int getById(int recordId) const;
  enum { notFound = -1 };
};

#endif // AddressBook_dot_h
