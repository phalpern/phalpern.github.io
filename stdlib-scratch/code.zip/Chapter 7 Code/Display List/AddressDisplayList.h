// TinyPIM (c) 1999 Pablo Halpern. File AddressDisplayList.h

#ifndef AddressDisplayList_dot_h
#define AddressDisplayList_dot_h 1

#include "DisplayList.h"

class AddressBook;

// Specialized DisplayList for Address records.
class AddressDisplayList : public DisplayList
{
public:
  // Construct with a reference to the address book
  AddressDisplayList(AddressBook& addrBook);

  // Scroll to first Address with name greater-than-or-equal to 
  // specified name. Usually, this will be a name that starts with
  // the specified strings. Returns false if no match found.
  bool findNameStartsWith(const std::string& lastname, 
                          const std::string& firstname = "");

  // List only those records that contain the specified string
  void listContainsString(const std::string&);

  // List all records (use after a listContainsString)
  void listAll();

protected:
  // Display the specified address record in one-line format.
  // Implements pure virtual base-class function.
  virtual void displayRecord(int recordId);

  // Override base-class function to retrieve more records.
  virtual bool fetchMore(int startId, int numRecords,
                         std::vector<int>& result);

private:
  AddressBook&	addressBook_;

  // String to use for listContainsString mode.
  std::string   containsString_;
};

#endif // AddressDisplayList_dot_h
