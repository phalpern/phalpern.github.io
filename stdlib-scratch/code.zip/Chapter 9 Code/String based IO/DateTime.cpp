// TinyPIM (c) 1999 Pablo Halpern. File DateTime.cpp

#include <iomanip>
#include <sstream>
#include "DateTime.h"

#ifndef _MSC_VER
using std::mktime;
using std::localtime;
using std::time_t;
#endif

DateTime::DateTime(int year, int month, int day, int hour, int min)
{
  set(year, month, day, hour, min);
}

void DateTime::get(int& year, int& month, int& day,
                   int& hour, int& min) const
{
  std::tm* mytm = localtime(&theTime_);
  year  = mytm->tm_year + 1900;
  month = mytm->tm_mon + 1;
  day   = mytm->tm_mday;
  hour  = mytm->tm_hour;
  min   = mytm->tm_min;
}

DateTime& DateTime::set(int year, int month, int day, 
                        int hour, int min)
{
  // Years from 0 - 49 are assumed to mean 2000 - 2049.
  // Years 1900 or over are assumed to be 4-digit years.
  // Other years are assumed to mean 1950 - 1999.
  if (year < 50)
    year += 2000;
  else if (year < 1900)
    year += 1900;

  std::tm mytm;
  mytm.tm_year = year - 1900;
  mytm.tm_mon  = month - 1; // zero based
  mytm.tm_mday = day;
  mytm.tm_hour = hour;
  mytm.tm_min  = min;
  mytm.tm_sec  = 0;
  mytm.tm_isdst = -1;

  theTime_ = mktime(&mytm);

  return *this;
}

// Get the current date and time
DateTime DateTime::now()
{
  DateTime ret;
  ret.theTime_ = time(0);  // Call std::time
  return ret;
}

std::ostream& operator<<(std::ostream& os, const DateTime& dt)
{
  std::ostringstream tmpstrm;

  std::tm theTm = *localtime(&dt.theTime_);

  tmpstrm << (theTm.tm_mon + 1) << '/'
          << theTm.tm_mday << '/'
          << (theTm.tm_year + 1900) << ' ';

  int hour = theTm.tm_hour % 12;
  const char* ampm = (theTm.tm_hour < 12 ? "am" : "pm");

  if (hour == 0)
    hour = 12;

  tmpstrm << std::setfill(' ') << std::right << std::setw(2) << hour
          << ':' << std::setfill('0') << std::right << std::setw(2) 
          << theTm.tm_min << ampm;

  return os << tmpstrm.str();
}

std::istream& operator>>(std::istream& is, DateTime& dt)
{
  // First, read the date part
  std::string date;
  is >> date;
  if (is.fail())
    return is;  // I/O error

  char slash1, slash2, colon;
  int mon, day, year, hour, min;
  char ampm[3];

  // Unpack the date part using a stringstream
  std::istringstream tmpstrm(date);
  tmpstrm >> mon >> slash1 >> day >> slash2 >> year;

  // Check for error in date
  if (tmpstrm.fail() || slash1 != '/' || slash2 != '/' ||
      mon < 1 || 12 < mon || day < 1 || 31 < day)
  {
    // format error, set fail bit and return
    is.clear(std::ios::failbit);
    return is;
  }

  // Now read the time part
  std::string time;
  is >> time;
  if (is.fail())
    return is;  // I/O error

  // Unpack the time part using the stringstream
  // Do not read am/pm indicator yet
  tmpstrm.clear();
  tmpstrm.str(time);
  tmpstrm >> hour >> colon >> min;

  // Check for error in time
  if (tmpstrm.fail() || hour < 0 || 23 < hour || min < 0 || 59 < min)
  {
    // format error, set fail bit and return
    is.clear(std::ios::failbit);
    return is;
  }

  // Check for am/pm indicator
  tmpstrm >> std::setw(3) >> ampm;
  bool useAmPm = ! tmpstrm.fail();

  // Convert hour from 12-hour to 24-hour format (0-23)
  if (useAmPm)
  {
    if (hour == 12)
      hour = 0;
    if (ampm[0] == 'p' || ampm[0] == 'P')
      hour += 12;
  }

  dt = DateTime(year, mon, day, hour, min);

  return is;
}

