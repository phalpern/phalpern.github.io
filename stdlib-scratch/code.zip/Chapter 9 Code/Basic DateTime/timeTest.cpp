// TinyPIM (c) 1999 Pablo Halpern. File timeTest.cpp

#include <iomanip>
#include "DateTime.h"

int main()
{
  // Test now() function
  std::cout << "Now = " << DateTime::now() << std::endl;

  // Test constructor
  std::cout << "Party = " << DateTime(0, 1, 1, 0, 0) << std::endl;

  DateTime dt;

  while (std::cin)
  {
    std::cout << "\nEnter a date and time: ";
    if (std::cin.peek() == 'q' || std::cin.peek() == 'Q' )
      break;

    std::cin >> dt;
    if (std::cin.fail())
    {
      std::cout << "Bad input" << std::endl;
      std::cin.clear();
    }
    else
    {
      std::cout << "DateTime = " << dt << std::endl;

      std::cout << std::setfill('*') << std::left << std::setw(30) 
                << std::hex << dt
                << ' ' << std::setw(10) << 0xff << std::endl;
    }

    std::cin.ignore(INT_MAX, '\n');   // If fails, loop will exit
  }

  return 0;
}
