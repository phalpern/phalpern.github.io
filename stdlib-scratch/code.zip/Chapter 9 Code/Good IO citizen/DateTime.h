// TinyPIM (c) 1999 Pablo Halpern. File DateTime.h

#ifndef DateTime_dot_h
#define DateTime_dot_h 1

#include <iostream>
#include <string>
#include <ctime>

#ifdef _MSC_VER
// Make sure these types and functions are in namespace std:
namespace std {
  typedef ::time_t time_t; 
  typedef ::tm tm;
  inline double difftime(time_t t1, time_t t0) 
    { return ::difftime(t1, t0); }
}
#endif

class DateTime
{
public:
  DateTime() : theTime_(0) { }
  DateTime(int year, int month, int day, int hour, int min);

  // Use compiler generated copy constructor, assignment, destructor
  
  // Read accessors
  void get(int& year, int& month, int& day,
           int& hour, int& min) const;

  // Write accessors
  DateTime& set(int year, int month, int day, int hour, int min);

  // Get the current date and time
  static DateTime now();

  friend bool operator==(const DateTime& dt1, const DateTime& dt2)
    { return dt1.theTime_ == dt2.theTime_; }

  friend bool operator<(const DateTime& dt1, const DateTime& dt2)
    { return std::difftime(dt1.theTime_, dt2.theTime_) < 0; }

  friend std::ostream& operator<<(std::ostream& os,
                                  const DateTime& dt);
  friend std::istream& operator>>(std::istream& is, DateTime& dt);

private:

  std::time_t theTime_;
};


#endif // DateTime_dot_h
