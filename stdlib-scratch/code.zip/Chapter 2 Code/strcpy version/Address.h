// TinyPIM (c) 1999 Pablo Halpern, File Address.h

#ifndef Address_dot_h
#define Address_dot_h 1

// Address class implemented using fixed-length strings
class Address
{
public:
  // Constructor
  Address();

  // Field accessors
  const char* lastname() const { return lastname_; }
  void lastname(const char*);

  const char* firstname() const { return firstname_; }
  void firstname(const char*);

  const char* phone() const { return phone_; }
  void phone(const char*);

  const char* address() const { return address_; }
  void address(const char*);

private:
  // Enumerate string lengths
  enum { namelen = 16, phonelen = 16, addrlen = 100 };

  // Data Fields
  char lastname_[namelen];
  char firstname_[namelen];
  char phone_[phonelen];
  char address_[addrlen];
};

#endif // Address_dot_h
