// TinyPIM (c) 1999 Pablo Halpern, File Address.cpp

#include <cstring>

#ifdef _MSC_VER
// This definition is needed for the Microsoft 6.0 compiler, which
// doesn't put strcpy into namespace std.
namespace std {
  char* strcpy(char *s1, const char* s2) { return ::strcpy(s1, s2); }
}
#endif

#include "Address.h"

Address::Address()
{
  // Initialize all strings to empty.
  lastname_[0] = firstname_[0] = phone_[0] = address_[0] = '\0';
}

void Address::lastname(const char* s)
{
  std::strcpy(lastname_, s);
}

void Address::firstname(const char* s)
{
  std::strcpy(firstname_, s);
}

void Address::phone(const char* s)
{
  std::strcpy(phone_, s);
}

void Address::address(const char* s)
{
  std::strcpy(address_, s);
}

