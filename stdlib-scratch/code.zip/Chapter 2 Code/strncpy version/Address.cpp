// TinyPIM (c) 1999 Pablo Halpern, File Address.cpp

#include <cstring>

#ifndef _MSC_VER
// These declarations for non-Microsoft compiler. Not needed
// for MSC because these functions are not in namespace std
// in the MSC compiler.
using std::strncpy;
#endif

#include "Address.h"

Address::Address()
{
  // Initialize all strings to empty.
  lastname_[0] = firstname_[0] = phone_[0] = address_[0] = '\0';
}

void Address::lastname(const char* s)
{
  strncpy(lastname_, s, namelen);
}

void Address::firstname(const char* s)
{
  strncpy(firstname_, s, namelen);
}

void Address::phone(const char* s)
{
  strncpy(phone_, s, phonelen);
}

void Address::address(const char* s)
{
  strncpy(address_, s, addrlen);
}

