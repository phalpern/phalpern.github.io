// TinyPIM (c) 1999 Pablo Halpern. File Address.cpp

#include <cstring>

#ifndef _MSC_VER
using std::strncpy;
#endif

#include "Address.h"

Address::Address()
{
  // Initialize all strings to empty.
  lastname_[0] = firstname_[0] = phone_[0] = address_[0] = '\0';
}

void Address::lastname(const char* s)
{
  strncpy(lastname_, s, namelen - 1);
  lastname_[namelen - 1] = '\0';
}

void Address::firstname(const char* s)
{
  strncpy(firstname_, s, namelen - 1);
  firstname_[namelen - 1] = '\0';
}

void Address::phone(const char* s)
{
  strncpy(phone_, s, phonelen - 1);
  phone_[phonelen - 1] = '\0';
}

void Address::address(const char* s)
{
  strncpy(address_, s, addrlen - 1);
  address_[addrlen - 1] = '\0';
}

