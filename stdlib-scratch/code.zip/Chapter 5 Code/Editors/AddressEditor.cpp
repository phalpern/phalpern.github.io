// TinyPIM (c) 1999 Pablo Halpern. File AddressEditor.cpp

#include <iostream>

#include "AddressEditor.h"

// Start with an empty Address object.
AddressEditor::AddressEditor()
{
}


// Edit an existing Address object
AddressEditor::AddressEditor(const Address& a)
  : addr_(a)
{
}

// Main loop returns true if address was successfully edited,
// false if edit was aborted.
bool AddressEditor::edit()
{
  // Unpack the address
  std::string lastname(addr_.lastname());
  std::string firstname(addr_.firstname());
  std::string phone(addr_.phone());
  std::string address(addr_.address());

  editSingleLine("Last name", lastname) &&
  editSingleLine("First name", firstname) &&
  editSingleLine("Phone Number", phone) &&
  editMultiLine("Address", address);

  if (status() == canceled)
    return false;

  // Commit changes
  addr_.lastname(lastname);
  addr_.firstname(firstname);
  addr_.phone(phone);
  addr_.address(address);

  return status() != canceled;
}
