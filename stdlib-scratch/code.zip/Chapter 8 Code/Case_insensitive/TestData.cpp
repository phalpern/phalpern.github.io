// TinyPIM (c) 1999 Pablo Halpern. File TestData.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <cstdlib>
#include <sstream>
#include <iomanip>

#ifdef _MSC_VER
namespace std { 
  inline int rand() { return ::rand(); }
  inline void srand(unsigned s) { ::srand(s); }
}
#endif

#include "AddressBook.h"

#ifndef __GNUC__ // Following code doesn't work on egcs 1.1.2:

// Return a string at random from a constant array of strings
template <class A>
inline const char* randomString(A& stringArray)
{
  int size = sizeof(A) / sizeof(stringArray[0]);
  int index = std::rand() % size;
  return stringArray[index];
}

#else  // __GNUC__ - This code subsitutes for problem code above

inline const char* _randomString(const char* const stringArray[], int size)
{
  int index = std::rand() % size;
  return stringArray[index];
}

#define randomString(a) _randomString(a, sizeof(a) / sizeof(a[0]))

#endif

void generateAddresses(AddressBook& addrbook, int numAddresses)
{
  // Seed the random number generator with a constant so that the
  // same sequence of "random" numbers will be generated every time.
  std::srand(100);

  static const char* const lastnames[] = {
    "Clinton", "Bush", "Reagan", "Carter", "Ford", "Nixon", "Johnson",
    "Kennedy"
  };

  static const char* const firstnames[] = {
    "William", "George", "Ronald", "Jimmy", "Gerald", "Richard",
    "Lyndon", "Jack", "Hillary", "Barbara", "Nancy", "Rosalynn",
    "Betty", "Pat", "Ladybird", "Jackie"
  };

  // The names of trees are used to generate street and town names.
  static const char* const trees[] = {
    "Maple", "Oak", "Willow", "Pine", "Hemlock", "Redwood", "Fir",
    "Holly", "Elm"
  };

  static const char* const streetSuffixes[] = {
    "St.", "Rd.", "Ln.", "Terr.", "Ave."
  };

  static const char* const townSuffixes[] = {
    "ton", "vale", "burg", "ham"
  };

  // State abbreviations, U.S. and its territories.
  // Thanks to the USPS Web page:
  // http://www.usps.gov/cpim/ftp/pubs/201html/addrpack.htm#abbr
  static const char* const states[] = {
    "AL", "AK", "AS", "AZ", "AR", "CA", "CO", "CT", "DE",
    "DC", "FM", "FL", "GA", "GU", "HI", "ID", "IL", "IN",
    "IA", "KS", "KY", "LA", "ME", "MH", "MD", "MA", "MI",
    "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM",
    "NY", "NC", "ND", "MP", "OH", "OK", "OR", "PA", "PR",
    "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "VI",
    "WA", "WV", "WI", "WY"
  };
  
  for (int i = 0; i < numAddresses; ++i)
  {
    Address addr;
    addr.lastname(randomString(lastnames));
    addr.firstname(randomString(firstnames));

    // Construct a phone number by streaming to a stringstream
    std::stringstream phonestream;
    phonestream << '(' << (std::rand() % 800 + 200) << ") "
		<< (std::rand() % 800 + 200) << '-'
		<< std::setfill('0') << std::setw(4) 
                << (std::rand() % 10000);
    addr.phone(phonestream.str());

    std::stringstream addrstream;
    // Generate number and street.
    addrstream << (std::rand() % 100 + 1) << " "
	       << randomString(trees) << " " 
               << randomString(streetSuffixes) << '\n';

    // Generate town name, state, and zip.
    addrstream << randomString(trees) << randomString(townSuffixes)
               << ", " << randomString(states) << " " 
	       << std::setfill('0') << std::setw(5) 
               << (std::rand() % 99999 + 1);
    addr.address(addrstream.str());

    addrbook.insertAddress(addr);
  }
}
