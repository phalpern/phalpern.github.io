// TinyPIM (c) 1999 Pablo Halpern

#include <iostream>

#include "AddressEditor.h"

// Start with an empty Address object.
AddressEditor::AddressEditor()
{
}


// Edit an existing Address object
AddressEditor::AddressEditor(const Address& a)
  : addr_(a)
{
}

// Main loop returns true if address was successfully edited,
// false if edit was aborted.
bool AddressEditor::edit()
{
  // Unpack the address
  std::string lastname(addr_.lastname());
  std::string firstname(addr_.firstname());
  std::string phone(addr_.phone());
  std::string address(addr_.address());

  editSingleLine("Last name", lastname) &&
  editSingleLine("First name", firstname) &&
  editPhone("Phone Number", phone) &&
  editMultiLine("Address", address);

  if (status() == canceled)
    return false;

  // Commit changes
  addr_.lastname(lastname);
  addr_.firstname(firstname);
  addr_.phone(phone);
  addr_.address(address);

  return status() != canceled;
}

bool AddressEditor::editPhone(const std::string& prompt,
                              std::string& phone)
{
  if (! editSingleLine(prompt, phone))
    return false;

  // Set the phone number.
  // Phone numers are converted into standard US notation.
  // Transformations of input string:
  //    7 digits	      => ddd-dddd
  //    '1' + 7 digits  => 1-ddd-dddd
  //    10 digits       => (ddd) ddd-dddd
  //    '1' + 10 digits => 1 (ddd) ddd-dddd
  // Identify suffix that contains uncommon phone-number characters
  static const std::string digits("0123456789");
  std::string::size_type suffix = 
      phone.find_first_not_of(digits + "-()/. ");
  if (suffix == std::string::npos)
    suffix = phone.length();

  // Extend suffix back to include non-digits after the last digit.
  suffix = phone.find_last_of(digits, suffix);
  if (suffix == std::string::npos)
    return true;   // prefix contains no digits. No reformatting.
  ++suffix;   // Advance suffix to exclude last digit

  // Okay, prefix string contains only digits and normal punctuation
  // Copy digits only to new phone number.
  std::string newnum;
  std::string::size_type p = phone.find_first_of(digits);
  while (p < suffix)
  {
    std::string::size_type q = phone.find_first_not_of(digits, p);
    // The range [p, q) contains only digits.
    // Append them to new number.
    newnum.append(phone, p, q - p);
    if (q == std::string::npos)
      break;
    p = phone.find_first_of(digits, q);
  }

  // Now we insert just the punctuation we want:
  switch (newnum.length())
  {
  case 7:
    newnum.insert(3, 1, '-');
    break;

  case 8:
    if (newnum[0] != '1')
      return true;	// 8-digit number not starting with '1'.

    newnum.insert(4, 1, '-');
    newnum.insert(1, 1, '-');
    break;

  case 10:
    newnum.insert(6, 1, '-');
    newnum.insert(3, ") ");
    newnum.insert((unsigned) 0, 1, '(');
    break;

  case 11:
    if (newnum[0] != '1')
      return true;	// 11-digit number not starting with '1'.

    newnum.insert(7, 1, '-');
    newnum.insert(4, ") ");
    newnum.insert(1, " (");
    break;

  default:
    return true;   // non-standard number of digits
  }

  // Number has been punctuated. Append suffix.
  phone.replace(0, suffix, newnum);
  return true;
}
