// TinyPIM (c) 1999 Pablo Halpern. File TinyPIM.cpp

#ifdef _MSC_VER
#pragma warning(disable : 4786)
#endif

#include <iostream>

#include "AddressBook.h"
#include "AddressBookMenu.h"

// Test function to generate addresses (in TestAddrData.cpp)
extern void generateAddresses(AddressBook& addrbook, 
                              int numAddresses);

// Main program just calls main menu, for now.
int main()
{
  AddressBook addrBook;

  // Generate 50 random address-book entries
  generateAddresses(addrBook, 50);

  // Create address book menu and push on menu stack
  AddressBookMenu addrBookMenu(addrBook);
  Menu::enterMenu(&addrBookMenu);

  // Process menu choices until menu exits.
  while (Menu::isActive())
    Menu::activeMenu()->mainLoop();

  std::cout << "\nThank you for using TinyPIM!\n" << std::endl;

  return 0;
}