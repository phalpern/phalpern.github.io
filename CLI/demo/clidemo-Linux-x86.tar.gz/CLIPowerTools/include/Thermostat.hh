/* Copyright (C) 2002 Halpern-Wight Software, Inc. All rights reserved. */

/******************************************************************************
 * Copyright (C) 2002 Halpern-Wight Software, Inc.  All rights reserved.
 *
 *****************************************************************************/

#ifndef Thermostat_dot_h
#define Thermostat_dot_h 1

#include <ctime>

// Class to represent a thermostat
class Thermostat
{
public:
  // Anonymous enumeration of day values. These values can be bit-wise ORed
  // together to express any combination of days of the week.
  enum {
    NoDay,
    Mondays    = 0x01,
    Tuesdays   = 0x02,
    Wednesdays = 0x04,
    Thursdays  = 0x08,
    Fridays    = 0x10,
    Saturdays  = 0x20,
    Sundays    = 0x40,
    Weekdays   = 0x1f,
    Weekends   = 0x60,
    Everyday   = 0x7f
  };

  struct Event
  {
    int         id_;
    unsigned    days_;
    std::time_t time_;
    int         temperature_;

    Event(int id, unsigned days, std::time_t time, int temperature)
      : id_(id), days_(days), time_(time), temperature_(temperature) { }
    Event() : id_(-1), days_(NoDay), time_(0), temperature_(0) { }
  };

  enum { MAX_EVENTS = 10 };

public:
  Thermostat();

  // Manage event list.
  unsigned numEvents() const { return numEvents_; }
  int addEvent(const Event& e);	// Returns new event ID or -1.
  int eraseEvent(unsigned id);  // Return -1 if no such event
  int eraseEvent(const Event& e) { return eraseEvent(e.id_); }
  int replaceEvent(const Event& e);

  // Retrieve event by ID. If no such event, return an empty event.
  const Event& getEvent(unsigned id) const;

  // Retrieve event IDs from event list. If input id == -1, return first event.
  // If no more events in list, return -1.
  int nextEventId(int id) const;
  int firstEventId() const { return nextEventId(-1); }

private:
  Event events_[MAX_EVENTS];
  unsigned numEvents_;
};

const unsigned NUM_THERMOSTATS = 4;
extern Thermostat Thermostats[NUM_THERMOSTATS];

#endif /* Thermostat_dot_h */
