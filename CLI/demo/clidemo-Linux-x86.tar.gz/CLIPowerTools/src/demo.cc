/* Copyright (C) 2002 Halpern-Wight Software, Inc. All rights reserved. */

#include <iostream>

extern "C" {
#   include <unistd.h>
}

#include "CliMain.hh"

int main()
{
    CliContext* context = CliContext::get_context();

    // Bracket this section so that hostname[] array is as short-lived
    // as possible.
    {
	char hostname[256];
	if (gethostname(hostname, 256) < 0)
	    context->setVariable("HOST", "demo");
	else
	    context->setVariable("HOST", hostname);
    }

    // Non-privilaged prompt is '>'
    context->setVariable("PRIV_PROMPT", ">");

    std::cout << "CLI Power Tools Demonstration.\n"
	      << "Copyright (c) 2002 Halpern-Wight Software, Inc.\n"
	      << "http://www.halpernwightsoftware.com\n"
	      << std::endl;

    return CliMainLoop();
}

// End demo.cc

