/* Copyright (C) 2002 Halpern-Wight Software, Inc. All rights reserved. */

/******************************************************************************
 * Copyright (C) 2002 Halpern-Wight Software, Inc.  All rights reserved.
 *
 *****************************************************************************/

#include "Thermostat.hh"

Thermostat::Thermostat() : numEvents_(0)
{
}

// Returns new event ID or -1.
int Thermostat::addEvent(const Event& e)
{
  // Look for an empty slot.
  for (int id = 0; id < MAX_EVENTS; ++id)
  {
    if (events_[id].id_ == -1)
    {
      events_[id] = e;
      events_[id].id_ = id;
      ++numEvents_;
      return id;
    }
  }

  // No empty slots.
  return -1;
}

int Thermostat::eraseEvent(unsigned id)
{
  if (id < 0 || id >= MAX_EVENTS)
    return -1;

  if (events_[id].id_ == -1)
    return -1;

  events_[id].id_ = -1;
  --numEvents_;
  return id;
}

int Thermostat::replaceEvent(const Event& e)
{
  if (e.id_ < 0 || e.id_ >= MAX_EVENTS)
    return -1;

  events_[e.id_] = e;
  return e.id_;
}

// Retrieve event by ID. If no such event, return an empty event.
const Thermostat::Event& Thermostat::getEvent(unsigned id) const
{
  static const Event nullEvent;

  if (id < 0 || id >= MAX_EVENTS)
    return nullEvent;
  else if (events_[id].id_ < 0)
    return nullEvent;
  else
    return events_[id];
}

// Retrieve event IDs from event list. If input id == -1, return first event.
// If no more events in list, return -1.
int Thermostat::nextEventId(int id) const
{
  if (id < -1)
    return -1;

  // Find next non-empty event
  while (++id < MAX_EVENTS)
    if (events_[id].id_ == id)
      return id;

  return -1;
}

Thermostat Thermostats[NUM_THERMOSTATS];
